﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Tc.Gny.SOAApi.Call;
using TC.GuoNeiYou.Common.BLL;

namespace Tc.Gny.SOAApi.Client
{
    class Program
    {
        static void Main(string[] args)
        {
            string xx = "LabelNames\":[\"三星级\"]},{\"LabelType\":\"游玩线路\",";

            var str =  WordValidateHelper.FilterForStr(xx);
            Console.ReadKey();
        }
    }
}
