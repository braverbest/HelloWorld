﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tc.Gny.SOAApi.Common.EOrder;

namespace Tc.Gny.SOAApi.Entities.EOrder.Order
{
    public class CLineOrderViewModel : CLineOrderModel
    {
        /// <summary>
        /// 订单状态描述
        /// </summary>
        /// <value>
        /// The order flag desc.
        /// </value>
        /// { Created At Time:[ 2016/3/23 17:28 ], By User:wcj21259, On Machine:WCJ }
        public string OrderFlagDesc
        {

            get
            {
                return EnumExt.GetOrderFlag(OrderFlag);
            }

        }

        ///// <summary>
        ///// 线路列表.
        ///// </summary>
        ///// <value>
        ///// The line information list.
        ///// </value>
        ///// { Created At Time:[ 2016/3/22 13:58 ], By User:wcj21259, On Machine:WCJ }
        //public CLineOrderDetail LineInfo { get; set; }

        ///// <summary>
        ///// 乘客列表.
        ///// </summary>
        ///// <value>
        ///// The passenger list.
        ///// </value>
        ///// { Created At Time:[ 2016/3/22 13:54 ], By User:wcj21259, On Machine:WCJ }
        //public IEnumerable<CLineOrderPassenger> PassengerList { get; set; }

        ///// <summary>
        ///// 订单价格列表.
        ///// </summary>
        ///// <value>
        ///// The order price list.
        ///// </value>
        ///// { Created At Time:[ 2016/3/25 10:42 ], By User:wcj21259, On Machine:WCJ }
        //public IEnumerable<CLineOrderPrice> OrderPriceList { get; set; }

        ///// <summary>
        ///// 采销酒店信息列表.
        ///// </summary>
        ///// <value>
        ///// The cx hotel order list.
        ///// </value>
        ///// { Created At Time:[ 2016/3/25 10:50 ], By User:wcj21259, On Machine:WCJ }
        //public IEnumerable<CXHotelOrder> CXHotelOrderList { get; set; }

        ///// <summary>
        ///// 附加费订单表.
        ///// </summary>
        ///// <value>
        ///// The extra charge order list.
        ///// </value>
        ///// { Created At Time:[ 2016/3/25 10:53 ], By User:wcj21259, On Machine:WCJ }
        //public IEnumerable<ExtraChargeOrder> ExtraChargeOrderList { get; set; }

        ///// <summary>
        ///// 航班信息列表.
        ///// </summary>
        ///// <value>
        ///// FlightList.
        ///// </value>
        ///// { Created At Time:[ 2016/3/22 17:17 ], By User:wcj21259, On Machine:WCJ }
        //public IEnumerable<FlightOrder> FlightList { get; set; }

        ///// <summary>
        ///// 航班乘客表.
        ///// </summary>
        ///// <value>
        ///// FlightOrderPriceList.
        ///// </value>
        ///// { Created At Time:[ 2016/3/25 11:06 ], By User:wcj21259, On Machine:WCJ }
        //public IEnumerable<FlightOrderPrice> FlightOrderPriceList { get; set; }

        ///// <summary>
        ///// 酒店信息列表.
        ///// </summary>
        ///// <value>
        ///// The hotel list.
        ///// </value>
        ///// { Created At Time:[ 2016/3/22 17:17 ], By User:wcj21259, On Machine:WCJ }
        //public IEnumerable<HotelOrderViewModel> HotelList { get; set; }

        ///// <summary>
        ///// 保险信息.
        ///// </summary>
        ///// <value>
        ///// My property.
        ///// </value>
        ///// { Created At Time:[ 2016/3/22 14:15 ], By User:wcj21259, On Machine:WCJ }
        //public IEnumerable<InsuranceDetail> InsuranceList { get; set; }

        ///// <summary>
        ///// 对外付款表.
        ///// </summary>
        ///// <value>
        ///// The order external pay list.
        ///// </value>
        ///// { Created At Time:[ 2016/3/25 11:30 ], By User:wcj21259, On Machine:WCJ }
        //public IEnumerable<OrderExternalPay> OrderExternalPayList { get; set; }

        ///// <summary>
        ///// 订单操作轨迹.
        ///// </summary>
        ///// <value>
        ///// The order flag track.
        ///// </value>
        ///// { Created At Time:[ 2016/3/25 11:36 ], By User:wcj21259, On Machine:WCJ }
        //public IEnumerable<OrderFlagTrack> OrderFlagTrackList { get; set; }

        ///// <summary>
        ///// 立返信息列表.
        ///// </summary>
        ///// <value>
        ///// The order stand back cash list.
        ///// </value>
        ///// { Created At Time:[ 2016/3/25 14:40 ], By User:wcj21259, On Machine:WCJ }
        //public IEnumerable<OrderStandBackCash> OrderStandBackCashList { get; set; }

        ///// <summary>
        ///// 打包资源信息列表.
        ///// </summary>
        ///// <value>
        ///// The package resource order list.
        ///// </value>
        ///// { Created At Time:[ 2016/3/25 15:01 ], By User:wcj21259, On Machine:WCJ }
        //public IEnumerable<PackageResourceOrder> PackageResourceOrderList { get; set; }

        ///// <summary>
        ///// 打包资源价格信息列表.
        ///// </summary>
        ///// <value>
        ///// The package resource order list.
        ///// </value>
        ///// { Created At Time:[ 2016/3/25 14:44 ], By User:wcj21259, On Machine:WCJ }
        //public IEnumerable<PackageResourceOrderPrice> PackageResourceOrderPriceList { get; set; }

        ///// <summary>
        ///// 单产品订单列表.
        ///// </summary>
        ///// <value>
        ///// The single resource order.
        ///// </value>
        ///// { Created At Time:[ 2016/3/25 15:05 ], By User:wcj21259, On Machine:WCJ }
        //public IEnumerable<SingleResourceOrder> SingleResourceOrderList { get; set; }

        ///// <summary>
        ///// 单产品价格体系列表.
        ///// </summary>
        ///// <value>
        ///// The single resource order price list.
        ///// </value>
        ///// { Created At Time:[ 2016/3/25 15:06 ], By User:wcj21259, On Machine:WCJ }
        //public IEnumerable<SingleResourceOrderPrice> SingleResourceOrderPriceList { get; set; }

        ///// <summary>
        ///// 微信订单卡券列表.
        ///// </summary>
        ///// <value>
        ///// The tourism wx order card list.
        ///// </value>
        ///// { Created At Time:[ 2016/3/25 15:16 ], By User:wcj21259, On Machine:WCJ }
        //public IEnumerable<TourismWxOrderCard> TourismWxOrderCardList { get; set; }

        ///// <summary>
        ///// 采销交通行程表.
        ///// </summary>
        ///// <value>
        ///// The traffic travel order list.
        ///// </value>
        ///// { Created At Time:[ 2016/3/25 15:20 ], By User:wcj21259, On Machine:WCJ }
        //public IEnumerable<TrafficTravelOrder> TrafficTravelOrderList { get; set; }

        ///// <summary>
        ///// 动态火车票.
        ///// </summary>
        ///// <value>
        ///// The train order list.
        ///// </value>
        ///// { Created At Time:[ 2016/3/25 15:22 ], By User:wcj21259, On Machine:WCJ }
        //public IEnumerable<TrainOrder> TrainOrderList { get; set; }

        ///// <summary>
        ///// 火车票乘客表.
        ///// </summary>
        ///// <value>
        ///// The train order price.
        ///// </value>
        ///// { Created At Time:[ 2016/3/25 15:25 ], By User:wcj21259, On Machine:WCJ }
        //public IEnumerable<TrainOrderPrice> TrainOrderPriceList { get; set; }

        ///// <summary>
        ///// 采销交通订单表.
        ///// </summary>
        ///// <value>
        ///// The transport order list.
        ///// </value>
        ///// { Created At Time:[ 2016/3/25 15:30 ], By User:wcj21259, On Machine:WCJ }
        //public IEnumerable<TransportOrder> TransportOrderList { get; set; }

        ///// <summary>
        ///// 采销交通价格体系表.
        ///// </summary>
        ///// <value>
        ///// The transport order price list.
        ///// </value>
        ///// { Created At Time:[ 2016/3/25 15:34 ], By User:wcj21259, On Machine:WCJ }
        //public IEnumerable<TransportOrderPrice> TransportOrderPriceList { get; set; }

        ///// <summary>
        ///// 工单表.
        ///// </summary>
        ///// <value>
        ///// The work order list.
        ///// </value>
        ///// { Created At Time:[ 2016/3/25 15:37 ], By User:wcj21259, On Machine:WCJ }
        //public IEnumerable<WorkOrder> WorkOrderList { get; set; }

        ///// <summary>
        ///// 支付记录表.
        ///// </summary>
        ///// <value>
        ///// The finance order.
        ///// </value>
        ///// { Created At Time:[ 2016/3/25 15:41 ], By User:wcj21259, On Machine:WCJ }
        //public IEnumerable<FinanceOrder> FinanceOrderList { get; set; }

        ///// <summary>
        ///// 订单对账表.
        ///// </summary>
        ///// <value>
        ///// The finance order statement list.
        ///// </value>
        ///// { Created At Time:[ 2016/3/25 15:43 ], By User:wcj21259, On Machine:WCJ }
        //public IEnumerable<FinanceOrderStatement> FinanceOrderStatementList { get; set; }

        ///// <summary>
        ///// 分次支付记录表.
        ///// </summary>
        ///// <value>
        ///// The pay times list.
        ///// </value>
        ///// { Created At Time:[ 2016/3/25 15:50 ], By User:wcj21259, On Machine:WCJ }
        //public IEnumerable<PayTimes> PayTimesList { get; set; }
    }
}
