﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tc.Gny.SOAApi.Entities.EOrder.Order
{
    public class CLineOrderQueryModel : QueryModel
    {
        /// <summary>
        /// 会员ID.
        /// </summary>
        /// <value>
        /// The serialid.
        /// </value>
        /// { Created At Time:[ 2016/3/24 10:29 ], By User:wcj21259, On Machine:WCJ }
        public string MemberId { get; set; }

        /// <summary>
        /// 订单状态： N：待支付订单W:待同程确认A:申请单L:支付中S:已支付P:已发占位单 P2:已收【供】F:未签合同【客】F1:签约完毕【客】Q:已发出团通知书U:出游中
        /// E：回访完毕D：点评结束 R：申请退款R1：无人出游部分退款完成R2：全额退款完成 R3：退款申请驳回C：取消订单H:待点评.
        /// </summary>
        /// <value>
        /// The is pay.
        /// </value>
        /// { Created At Time:[ 2016/3/29 15:04 ], By User:wcj21259, On Machine:WCJ }
        public string OrderFlag { get; set; }
    }
}
