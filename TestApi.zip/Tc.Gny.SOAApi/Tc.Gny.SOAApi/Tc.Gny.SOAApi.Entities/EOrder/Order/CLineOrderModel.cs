﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tc.Gny.SOAApi.Entities.EOrder.Order
{
    /// <summary>
    /// 订单实体类
    /// </summary>
    /// { Created At Time:[ 2016/3/29 10:59 ], By User:wcj21259, On Machine:WCJ }
    public class CLineOrderModel
    {
        /// <summary>
        /// 主键.
        /// </summary>
        /// <value>
        /// The identifier.
        /// </value>
        /// { Created At Time:[ 2016/3/29 10:59 ], By User:wcj21259, On Machine:WCJ }
        public int Id { get; set; }

        /// <summary>
        /// 订单流水号.
        /// </summary>
        /// <value>
        /// The serialid.
        /// </value>
        /// { Created At Time:[ 2016/3/29 11:01 ], By User:wcj21259, On Machine:WCJ }
        public string Serialid { get; set; }

        /// <summary>
        /// 客户订单号.
        /// </summary>
        /// <value>
        /// The customer serialid.
        /// </value>
        /// { Created At Time:[ 2016/3/29 11:01 ], By User:wcj21259, On Machine:WCJ }
        public string CustomerSerialid { get; set; }

        /// <summary>
        /// 订单所属线路.
        /// </summary>
        /// <value>
        /// The line identifier.
        /// </value>
        /// { Created At Time:[ 2016/3/29 11:02 ], By User:wcj21259, On Machine:WCJ }
        public int LineId { get; set; }

        /// <summary>
        /// 订单状态： N：待支付订单W:待同程确认A:申请单L:支付中S:已支付P:已发占位单 P2:已收【供】F:未签合同【客】F1:签约完毕【客】
        /// Q:已发出团通知书U:出游中E：回访完毕D：点评结束 R：申请退款R1：无人出游部分退款完成R2：全额退款完成 R3：退款申请驳回
        /// C：取消订单H:待点评.
        /// </summary>
        /// <value>
        /// The order flag.
        /// </value>
        /// { Created At Time:[ 2016/3/29 11:02 ], By User:wcj21259, On Machine:WCJ }
        public string OrderFlag { get; set; }

        /// <summary>
        /// 结算总价.
        /// </summary>
        /// <value>
        /// The settlement price.
        /// </value>
        /// { Created At Time:[ 2016/3/29 11:03 ], By User:wcj21259, On Machine:WCJ }
        public decimal SettlementPrice { get; set; }

        /// <summary>
        /// 销售总价.
        /// </summary>
        /// <value>
        /// The sales price.
        /// </value>
        /// { Created At Time:[ 2016/3/29 11:03 ], By User:wcj21259, On Machine:WCJ }
        public decimal SalesPrice { get; set; }

        /// <summary>
        /// 实付金额.
        /// </summary>
        /// <value>
        /// The re pay amount.
        /// </value>
        /// { Created At Time:[ 2016/3/29 11:04 ], By User:wcj21259, On Machine:WCJ }
        public decimal RePayAmount { get; set; }

        /// <summary>
        /// 订单总人数.
        /// </summary>
        /// <value>
        /// The people count.
        /// </value>
        /// { Created At Time:[ 2016/3/29 11:04 ], By User:wcj21259, On Machine:WCJ }
        public int PeopleCount { get; set; }

        /// <summary>
        /// 联系人姓名.
        /// </summary>
        /// <value>
        /// The name of the contact.
        /// </value>
        /// { Created At Time:[ 2016/3/29 11:05 ], By User:wcj21259, On Machine:WCJ }
        public string ContactName { get; set; }

        /// <summary>
        /// 联系人电话.
        /// </summary>
        /// <value>
        /// The contact mobile.
        /// </value>
        /// { Created At Time:[ 2016/3/29 11:05 ], By User:wcj21259, On Machine:WCJ }
        public string ContactMobile { get; set; }

        /// <summary>
        /// 联系人邮箱.
        /// </summary>
        /// <value>
        /// The contact mail.
        /// </value>
        /// { Created At Time:[ 2016/3/29 11:05 ], By User:wcj21259, On Machine:WCJ }
        public string ContactMail { get; set; }

        /// <summary>
        /// 下单时间.
        /// </summary>
        /// <value>
        /// The order date.
        /// </value>
        /// { Created At Time:[ 2016/3/29 11:06 ], By User:wcj21259, On Machine:WCJ }
        public string OrderDate { get; set; }
        /// <summary>
        /// 支付时间.
        /// </summary>
        /// <value>
        /// The pay date.
        /// </value>
        /// { Created At Time:[ 2016/3/29 11:07 ], By User:wcj21259, On Machine:WCJ }
        public string PayDate { get; set; }

        /// <summary>
        /// 0：未支付，1：已支付（全部清款），2：支付中（部分清款）
        /// </summary>
        /// <value>
        /// The is pay.
        /// </value>
        /// { Created At Time:[ 2016/3/29 11:07 ], By User:wcj21259, On Machine:WCJ }
        public int IsPay { get; set; }

        /// <summary>
        /// 订单平台来源.
        /// </summary>
        /// <value>
        /// The order platform.
        /// </value>
        /// { Created At Time:[ 2016/3/29 11:09 ], By User:wcj21259, On Machine:WCJ }
        public int OrderPlatform { get; set; }

        /// <summary>
        /// 订单支付方式.
        /// </summary>
        /// <value>
        /// The type of the payment.
        /// </value>
        /// { Created At Time:[ 2016/3/29 11:12 ], By User:wcj21259, On Machine:WCJ }
        public int PaymentType { get; set; }

        /// <summary>
        /// 订单数据状态 0：无效，1：有效.
        /// </summary>
        /// <value>
        /// The data flag.
        /// </value>
        /// { Created At Time:[ 2016/3/29 11:13 ], By User:wcj21259, On Machine:WCJ }
        public int DataFlag { get; set; }

        /// <summary>
        /// 订单线路属性（1：跟团（跟团游），3：自助,自由行 5：目的地跟团）.
        /// </summary>
        /// <value>
        /// The line property.
        /// </value>
        /// { Created At Time:[ 2016/3/29 11:14 ], By User:wcj21259, On Machine:WCJ }
        public int LineProperty { get; set; }

        /// <summary>
        /// 第三方订单号.
        /// </summary>
        /// <value>
        /// The third party serialid.
        /// </value>
        /// { Created At Time:[ 2016/3/29 11:14 ], By User:wcj21259, On Machine:WCJ }
        public string ThirdPartySerialid { get; set; }

        /// <summary>
        /// 前处理分单责任人工号.
        /// </summary>
        /// <value>
        /// The gain handler job number.
        /// </value>
        /// { Created At Time:[ 2016/3/29 11:15 ], By User:wcj21259, On Machine:WCJ }
        public string GainHandlerJobNum { get; set; }

        /// <summary>
        /// 后处理分单人工号.
        /// </summary>
        /// <value>
        /// The reprocess handler job number.
        /// </value>
        /// { Created At Time:[ 2016/3/29 11:16 ], By User:wcj21259, On Machine:WCJ }
        public string ReprocessHandlerJobNum { get; set; }

        /// <summary>
        /// 产品类型.
        /// </summary>
        /// <value>
        /// The type of the product.
        /// </value>
        /// { Created At Time:[ 2016/3/29 11:16 ], By User:wcj21259, On Machine:WCJ }
        public int ProductType { get; set; }

        /// <summary>
        /// 保险金额.
        /// </summary>
        /// <value>
        /// The insurance amount.
        /// </value>
        /// { Created At Time:[ 2016/3/29 11:17 ], By User:wcj21259, On Machine:WCJ }
        public decimal InsuranceAmount { get; set; }

        /// <summary>
        /// 保险实付.
        /// </summary>
        /// <value>
        /// The insurance re amount.
        /// </value>
        /// { Created At Time:[ 2016/3/29 11:17 ], By User:wcj21259, On Machine:WCJ }
        public decimal InsuranceReAmount { get; set; }

        /// <summary>
        /// 门店编码.
        /// </summary>
        /// <value>
        /// The branch company identifier.
        /// </value>
        /// { Created At Time:[ 2016/3/29 11:23 ], By User:wcj21259, On Machine:WCJ }
        public int BranchCompanyId { get; set; }

        /// <summary>
        /// 出团日期.
        /// </summary>
        /// <value>
        /// The start date.
        /// </value>
        /// { Created At Time:[ 2016/3/29 11:23 ], By User:wcj21259, On Machine:WCJ }
        public string StartDate { get; set; }

        /// <summary>
        /// 回团日期.
        /// </summary>
        /// <value>
        /// The return date.
        /// </value>
        /// { Created At Time:[ 2016/3/29 11:25 ], By User:wcj21259, On Machine:WCJ }
        public string ReturnDate { get; set; }

        /// <summary>
        /// 0：表示未对账 1：表示对账中 2：表示对账结束.
        /// </summary>
        /// <value>
        /// The reconciliation flag.
        /// </value>
        /// { Created At Time:[ 2016/3/29 11:26 ], By User:wcj21259, On Machine:WCJ }
        public int ReconciliationFlag { get; set; }

        /// <summary>
        /// 取消原因ID.
        /// </summary>
        /// <value>
        /// The cancel reason identifier.
        /// </value>
        /// { Created At Time:[ 2016/3/29 11:26 ], By User:wcj21259, On Machine:WCJ }
        public int CancelReasonId { get; set; }

        /// <summary>
        /// 邮寄地址.
        /// </summary>
        /// <value>
        /// The post address.
        /// </value>
        /// { Created At Time:[ 2016/3/29 11:28 ], By User:wcj21259, On Machine:WCJ }
        public string PostAddress { get; set; }

        /// <summary>
        /// 会员ID.
        /// </summary>
        /// <value>
        /// The member identifier.
        /// </value>
        /// { Created At Time:[ 2016/3/29 11:28 ], By User:wcj21259, On Machine:WCJ }
        public int MemberId { get; set; }

        /// <summary>
        /// 微信OpenId.
        /// </summary>
        /// <value>
        /// The open identifier.
        /// </value>
        /// { Created At Time:[ 2016/3/29 11:29 ], By User:wcj21259, On Machine:WCJ }
        public string OpenId { get; set; }

        /// <summary>
        /// 优惠金额.
        /// </summary>
        /// <value>
        /// The discount amount.
        /// </value>
        /// { Created At Time:[ 2016/3/29 11:29 ], By User:wcj21259, On Machine:WCJ }
        public decimal DiscountAmount { get; set; }

        /// <summary>
        /// 客户备注.
        /// </summary>
        /// <value>
        /// The customer remark.
        /// </value>
        /// { Created At Time:[ 2016/3/29 11:29 ], By User:wcj21259, On Machine:WCJ }
        public string CustomerRemark { get; set; }

        /// <summary>
        /// 下单人工号.
        /// </summary>
        /// <value>
        /// The order job number.
        /// </value>
        /// { Created At Time:[ 2016/3/29 11:30 ], By User:wcj21259, On Machine:WCJ }
        public string OrderJobNumber { get; set; }

        /// <summary>
        /// 创建人.
        /// </summary>
        /// <value>
        /// The name of the create.
        /// </value>
        /// { Created At Time:[ 2016/3/29 11:30 ], By User:wcj21259, On Machine:WCJ }
        public string CreateName { get; set; }

        /// <summary>
        /// 部门ID.
        /// </summary>
        /// <value>
        /// The department identifier.
        /// </value>
        /// { Created At Time:[ 2016/3/29 11:31 ], By User:wcj21259, On Machine:WCJ }
        public string DepartmentId { get; set; }

        /// <summary>
        /// 区域（在各区域门店下单的记录）.
        /// </summary>
        /// <value>
        /// The area identifier.
        /// </value>
        /// { Created At Time:[ 2016/3/29 11:31 ], By User:wcj21259, On Machine:WCJ }
        public string AreaId { get; set; }

        /// <summary>
        /// 片区ID.
        /// </summary>
        /// <value>
        /// The assign area identifier.
        /// </value>
        /// { Created At Time:[ 2016/3/29 11:31 ], By User:wcj21259, On Machine:WCJ }
        public int AssignAreaId { get; set; }

        /// <summary>
        /// 变更时间.
        /// </summary>
        /// <value>
        /// The alter date.
        /// </value>
        /// { Created At Time:[ 2016/3/29 11:31 ], By User:wcj21259, On Machine:WCJ }
        public string AlterDate { get; set; }

        /// <summary>
        /// 订单实际收款金额.
        /// </summary>
        /// <value>
        /// The re all amount.
        /// </value>
        /// { Created At Time:[ 2016/3/29 11:32 ], By User:wcj21259, On Machine:WCJ }
        public decimal ReAllAmount { get; set; }

        /// <summary>
        /// 单房差价格.
        /// </summary>
        /// <value>
        /// The single roon price.
        /// </value>
        /// { Created At Time:[ 2016/3/29 11:32 ], By User:wcj21259, On Machine:WCJ }
        public decimal SingleRoomPrice { get; set; }

        /// <summary>
        /// 单房差数量.
        /// </summary>
        /// <value>
        /// The single room no.
        /// </value>
        /// { Created At Time:[ 2016/3/29 11:33 ], By User:wcj21259, On Machine:WCJ }
        public int SingleRoomNo { get; set; }

        /// <summary>
        /// 首呼时间.
        /// </summary>
        /// <value>
        /// The first call date.
        /// </value>
        /// { Created At Time:[ 2016/3/29 11:33 ], By User:wcj21259, On Machine:WCJ }
        public string FirstCallDate { get; set; }

        /// <summary>
        /// 是否测试订单 0：非测试，1：测试（过滤测试单都用这个）.
        /// </summary>
        /// <value>
        /// The is test.
        /// </value>
        /// { Created At Time:[ 2016/3/29 11:34 ], By User:wcj21259, On Machine:WCJ }
        public int IsTest { get; set; }

        /// <summary>
        /// 订单产品来源，0：正常订单，1：EB平台订单.
        /// </summary>
        /// <value>
        /// The product source.
        /// </value>
        /// { Created At Time:[ 2016/3/29 11:35 ], By User:wcj21259, On Machine:WCJ }
        public int ProductSource { get; set; }

        /// <summary>
        /// 参与的活动类型：0-普通订单  1-秒杀活动；2-限时特价；3-爆款抢购；4-品质享受；5-出境卡；（TCCLineOrder.dbo.IVProductSellType）
        /// </summary>
        /// <value>
        /// The type of the order.
        /// </value>
        /// { Created At Time:[ 2016/3/29 11:38 ], By User:wcj21259, On Machine:WCJ }
        public int OrderType { get; set; }
    }
}
