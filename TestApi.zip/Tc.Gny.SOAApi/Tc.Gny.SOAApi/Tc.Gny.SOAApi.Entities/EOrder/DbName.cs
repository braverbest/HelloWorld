﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tc.Gny.SOAApi.Entities.EOrder
{
    public static class DbName
    {
        public const string TCTourismEbooking = "TCTourismEbooking";
        public const string TcTourismLog = "TcTourismLog";
        public const string TCTourismResource = "TCTourismResource";
        public const string TCTourism = "TCTourism";
        public const string TCTourismBI = "TCTourismBI";
        public const string TcTourismOrder = "TcTourismOrder";
        public const string TCTourismCommunal = "TCTourismCommunal";
        public const string IBCC = "IBCC";
        public const string TCTourismEOrderLog = "TCTourismEOrderLog";
        public const string TCTourismEOrder = "TCTourismEOrder";
        public const string TCTourismEOrderServer = "TCTourismEOrderServer";
    }
}
