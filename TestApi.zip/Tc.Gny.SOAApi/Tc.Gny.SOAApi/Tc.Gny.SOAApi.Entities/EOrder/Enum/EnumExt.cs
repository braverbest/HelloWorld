﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using Tc.Gny.SOAApi.Entities.EOrder.Enum;

namespace Tc.Gny.SOAApi.Common.EOrder
{
    public class EnumItem
    {
        public string ItemText { get; set; }
        public string ItemValue { get; set; }
        public string ItemDes { get; set; }
        public const string ItemValueField = "ItemValue";
        public const string ItemTextField = "ItemText";
        public const string ItemDesField = "ItemDes";
    }

    public static class EnumExt
    {
        private static readonly ConcurrentDictionary<Type, Dictionary<string, EnumItem>> EnumAbout = new ConcurrentDictionary<Type, Dictionary<string, EnumItem>>();

        /// <summary>
        /// 获取备注
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static string GetDescription(this System.Enum value)
        {
            try
            {
                if (value == null) return "";
                FieldInfo field = value.GetType().GetField(value.ToString());
                return ((DescriptionAttribute)Attribute.GetCustomAttribute(field, typeof(DescriptionAttribute))).Description;
            }
            catch (Exception ex)
            {
                return value.ToString();
            }
        }

        /// <summary> 获取枚举类子项描述信息 </summary>
        /// <param name="enumtype">枚举类型</param>
        /// <param name="enumSubitem">值</param>        
        public static string GetEnumDescriptionByValue(System.Type enumtype, string strVlaue)
        {
            strVlaue = strVlaue ?? string.Empty;
            FieldInfo fi;
            DescriptionAttribute da;
            foreach (System.Enum enumValue in System.Enum.GetValues(enumtype))
            {
                fi = enumtype.GetField((enumValue.ToString()));
                da = (DescriptionAttribute)Attribute.GetCustomAttribute(fi, typeof(DescriptionAttribute));
                if (da != null && strVlaue.ToUpper() == enumValue.ToString().ToUpper())
                {
                    return da.Description ?? string.Empty;
                }
            }
            return string.Empty;
        }

        #region 将指定枚举类型转换成List

        /// <summary>
        /// 将指定枚举类型转换成List，用来绑定ListControl
        /// </summary>
        /// <param name="enumType">枚举类型</param>
        /// <param name="selectFeild">默认选择的项的值</param>
        /// <returns></returns>
        public static List<SelectListItem> ConvertEnumToList(Type enumType, string selectFeild = "")
        {
            if (enumType.IsEnum == false)
            {
                return null;
            }
            var typeDescription = typeof(DescriptionAttribute);
            var fields = enumType.GetFields();
            var selectListItems = new List<SelectListItem>();
            foreach (var field in fields.Where(field => !field.IsSpecialName))
            {
                var strValue = field.GetRawConstantValue().ToString();
                var arr = field.GetCustomAttributes(typeDescription, true);
                var strText = arr.Length > 0 ? ((DescriptionAttribute)arr[0]).Description : field.Name;

                var item = new SelectListItem { Text = strText, Value = strValue };

                if (strValue.Equals(selectFeild))
                    item.Selected = true;
                selectListItems.Add(item);
            }
            return selectListItems;
        }

        #endregion

        /// <summary>
        /// 获取订单状态
        /// </summary>
        /// <param name="orderFlag">订单状态</param>
        /// <returns></returns>
        public static string GetOrderFlag(string orderFlag)
        {
            string s = GetEnumDescriptionByValue(typeof(OrderEnum.OrderFlag), orderFlag);
            return string.IsNullOrEmpty(s) ? "其他" : s;
        }

    }
}
