﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tc.Gny.SOAApi.Entities.EOrder.Enum
{
    public class OrderEnum
    {
        /// <summary>
        /// 主订单乘客类型
        /// </summary>
        /// { Created At Time:[ 2016/3/29 13:55 ], By User:wcj21259, On Machine:WCJ }
        public enum OrderCustomerType
        {
            [Description("成人")]
            Adult = 1,
            [Description("儿童")]
            Child = 2,
            [Description("外籍人士")]
            Foreign = 3,
            [Description("儿童1.2m以下")]
            ChildHeightUnderOnePointTwo = 4,
            [Description("婴儿")]
            Baby = 5
        }

        /// <summary>
        /// 订单线路属性
        /// </summary>
        /// { Created At Time:[ 3/10/2016 11:16 AM ], By User:xr10112, On Machine:XR10112 }
        public enum OrderLineProperty
        {
            [Description("不区分")]
            不区分 = 0,
            [Description("跟团")]
            跟团 = 1,
            [Description("自由")]
            自由 = 3,
            [Description("目的地跟团")]
            目的地跟团 = 5
        }

        /// <summary>
        /// 订单渠道
        /// </summary>
        /// { Created At Time:[ 3/9/2016 2:49 PM ], By User:xr10112, On Machine:XR10112 }
        public enum OrderFromPlatmentEnum
        {
            [Description("需求单转化")]
            需求单转化 = 564,
            [Description("淘在路上")]
            淘在路上 = 566,
            [Description("热气球")]
            热气球 = 567,
            [Description("CN平台")]
            CN平台 = 1,
            [Description("CCT平台")]
            CCT平台 = 8,
            [Description("Touch站")]
            Touch站 = 432,
            [Description("客户端IOS")]
            客户端IOS = 433,
            [Description("客户端Android")]
            客户端Android = 434,
            [Description("京东度假")]
            京东度假 = 463,
            [Description("QQ旅游-touch")]
            QQ旅游touch = 527,
            [Description("QQ旅游客户端（Android）")]
            QQ旅游客户端Android = 535,
            [Description("蚂蜂窝")]
            团购蚂蜂窝 = 543,
            [Description("穷游")]
            团购穷游 = 544,
            [Description("来来会")]
            团购来来会 = 545,
            [Description("有特价")]
            团购有特价 = 546,
            [Description("麦图")]
            团购麦图 = 547,
            [Description("去哪玩	")]
            团购去哪玩 = 548,
            [Description("分销渠道-龙腾捷旅")]
            分销渠道龙腾捷旅 = 549,
            [Description("分销渠道-金威")]
            分销渠道金威 = 550,
            [Description("分销渠道-鑫享假期")]
            分销渠道鑫享假期 = 551,
            [Description("分销渠道-深圳捷旅")]
            分销渠道深圳捷旅 = 552,
            [Description("长线游线下渠道")]
            长线游线下渠道 = 553,
            [Description("去哪儿TTS下单")]
            去哪儿TTS下单 = 554,
            [Description("同行合作")]
            同行合作 = 555,
            [Description("淘宝网")]
            淘宝网 = 556,
            [Description("分公司")]
            分公司 = 557,
            [Description("外呼")]
            外呼 = 558,
            [Description("OP后台")]
            OP后台 = 559,
            [Description("电视台")]
            电视台 = 560,
            [Description("爱旅行")]
            团购爱旅行 = 561,
            [Description("专家转化")]
            专家转化 = 563,
            [Description("公共来源平台")]
            公共来源平台 = -50,
            [Description("PC")]
            PC = -1,
            [Description("客户端")]
            客户端 = -3,
            [Description("分销平台")]
            分销平台 = -4,
            [Description("QQ旅游")]
            QQ旅游 = -5,
            [Description("OP后台1")]
            OP后台1 = -6,
            [Description("其他")]
            其他 = 578,
            [Description("旅仓")]
            旅仓 = 64,
            [Description("面包旅行")]
            面包旅行 = 592,
            [Description("大众点评")]
            大众点评 = 593,
            [Description("去哪儿")]
            去哪儿 = 594,
            [Description("携程")]
            携程 = 595,
            [Description("微信")]
            微信 = 65,
            [Description("铂涛")]
            铂涛 = 598,
            [Description("外呼分销")]
            外呼1 = 256,
            [Description("美团")]
            美团 = 600,
            [Description("钱宝")]
            钱宝 = 601,
            [Description("淘宝线下")]
            淘宝线下 = 602,
            [Description("国青国旅")]
            国青国旅 = 603,
            [Description("千丁")]
            千丁 = 604,
            [Description("在外")]
            在外 = 605,
            [Description("唯品会")]
            唯品会 = 606,
            [Description("移动销售平台")]
            SalesPlatform = 747,
            [Description("会销")]
            Willpin = 777,
        }


        /// <summary>
        /// 所属部门
        /// </summary>
        public enum OrderGroupEnum
        {
            [Description("OP前处理")]
            OP前处理 = 1,
            [Description("OP后处理")]
            OP后处理 = 2,
            [Description("CCT")]
            CCT = 3,
            [Description("专家组")]
            专家组 = 4,
            [Description("航变退改组")]
            航变退改组 = 5,
        }


        /// <summary>
        ///  有效 /无效
        /// </summary>
        public enum DataFlag
        {
            [Description("无效")]
            无效 = 0,

            [Description("有效")]
            有效 = 1,
        }

        /// <summary>
        /// 归属公司名称
        /// </summary>
        public enum Company
        {
            [Description("同程国际旅行社有限公司")]
            同程国际旅行社有限公司 = 1,
            [Description("同程上海分公司")]
            同程上海分公司 = 2,
        }

        /// <summary>
        /// 证件类型
        /// </summary>
        public enum CertType
        {
            [Description("身份证")]
            身份证 = 1,

            [Description("护照")]
            护照 = 2,

            [Description("军官证")]
            军官证 = 3,

            [Description("台胞证")]
            台胞证 = 5,

            [Description("稍后提供")]
            稍后提供 = 6,

            [Description("港澳通行证")]
            港澳通行证 = 7,

            [Description("其它")]
            其它 = 9
        }

        /// <summary>
        /// 线路控位状态
        /// </summary>
        public enum PositionName
        {
            [Description("控位待审核")]
            控位待审核 = 0,
            [Description("控位待支付")]
            控位待支付 = 1,
            [Description("满位待审核")]
            满位待审核 = 2,
            [Description("未控位")]
            未控位 = 3,
        }

        /// <summary>
        /// 订单状态
        /// </summary>
        public enum OrderFlag
        {
            //订单状态： N：待支付订单W:待同程确认A:申请单L:支付中S:已支付P:已发占位单 P2:已收【供】F:未签合同【客】F1:签约完毕【客】
            //Q:已发出团通知书U:出游中E：回访完毕D：点评结束 R：申请退款R1：无人出游部分退款完成R2：全额退款完成 R3：退款申请驳回C：取消订单H:待点评
            [Description("待支付")]
            N,
            [Description("待同程确认")]
            W,
            [Description("申请单")]
            A,
            [Description("支付中")]
            L,
            [Description("已支付")]
            S,
            [Description("已发占位单")]
            P,
            [Description("已收【供】")]
            P2,
            [Description("未签合同【客】")]
            F,
            [Description("签约完毕【客】")]
            F1,
            [Description("已发出团通知书")]
            Q,
            [Description("出游中")]
            U,
            [Description("回访完毕")]
            E,
            [Description("点评结束")]
            D,
            [Description("申请退款")]
            R,
            [Description("无人出游部分退款完成")]
            R1,
            [Description("全额退款完成")]
            R2,
            [Description("退款申请驳回")]
            R3,
            [Description("取消订单")]
            C,
            [Description("待点评")]
            H
        }

        public enum Enum_ProductType
        {
            /// <summary>
            /// 默认
            /// </summary>
            /// { Created At Time:[ 2016/3/15 16:16 ], By User:wcj21259, On Machine:WCJ }
            [Description("默认")]
            Default = 0,
            /// <summary>
            /// 采销分离
            /// </summary>
            /// { Created At Time:[ 2016/3/15 16:17 ], By User:wcj21259, On Machine:WCJ }
            [Description("采销分离")]
            SPS = 1,
            /// <summary>
            /// 火车票自由组合
            /// </summary>
            /// { Created At Time:[ 2016/3/15 16:19 ], By User:wcj21259, On Machine:WCJ }
            [Description("火车票自由组合")]
            TrainFreeCombin = 2,
            /// <summary>
            /// 机票自由组合
            /// </summary>
            /// { Created At Time:[ 2016/3/15 16:19 ], By User:wcj21259, On Machine:WCJ }
            [Description("机票自由组合")]
            FlightFreeCombin = 3,
            /// <summary>
            /// 动态火车票组合
            /// </summary>
            /// { Created At Time:[ 2016/3/15 16:19 ], By User:wcj21259, On Machine:WCJ }
            [Description("动态火车票组合")]
            DynamicTrainCombin = 4,
            /// <summary>
            /// 机酒组合
            /// </summary>
            /// { Created At Time:[ 2016/3/15 16:19 ], By User:wcj21259, On Machine:WCJ }
            [Description("机酒组合")]
            FlightHotelCombin = 5,
            /// <summary>
            /// 火酒组合
            /// </summary>
            /// { Created At Time:[ 2016/3/15 16:20 ], By User:wcj21259, On Machine:WCJ }
            [Description("火酒组合")]
            TrainHotel = 6
        }

        /// <summary>
        /// 采销交通类型
        /// </summary>
        public enum TrafficType
        {

            [Description("默认")]
            默认 = 0,
            [Description("租车")]
            租车 = 1,
            [Description("轮船")]
            轮船 = 2,
            [Description("飞机")]
            飞机 = 3,
            [Description("火车")]
            火车 = 4,
            [Description("巴士")]
            巴士 = 5
        }

        /// <summary>
        /// 切位类型 
        /// </summary>
        public enum CuType
        {
            [Description("硬切")]
            硬切 = 1,
            [Description("软切")]
            软切 = 2,
            [Description("轮船")]
            询位 = 3,

        }
    }
}
