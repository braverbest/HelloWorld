﻿using System;
using Tc.Gny.Framework.ORM.Attrbuites;
using Tc.Gny.Framework.ORM.Base;

namespace Tc.Gny.SOAApi.Entities
{
    [Serializable]
    [Entity(@"SELECT dhr.TDHRLineId,dhr.TDHRCityId,dhr.TDHRBeginDay,dhr.TDHREndDay,
    pdh.TPDHotelId,pdh.TPDHRoomId,pdh.TPDHPolicyId
    FROM dbo.TourismDesHotelResource AS dhr WITH(NOLOCK)
    LEFT JOIN TourismProductDynamicHotel AS pdh WITH(NOLOCK) ON dhr.TDHRId=pdh.TPDHDesHotelResId
    WHERE dhr.TDHRDataFlag=1 AND pdh.TPDHDataFlag=1", true)]
    public partial class DynamicHotelResource : BaseEntity<DynamicHotelResource>
    {
        public const string DBNAME = "TcTourismResource";

        #region	属性

        /// <summary>
        /// 产品ID
        /// </summary>
        public int TDHRLineId
        {
            get;
            set;
        }
        /// <summary>
        /// 目的地城市ID
        /// </summary>
        public int TDHRCityId
        {
            get;
            set;
        }
        /// <summary>
        /// 开始晚数
        /// </summary>
        public int TDHRBeginDay
        {
            get;
            set;
        }
        /// <summary>
        /// 结束晚数
        /// </summary>
        public int TDHREndDay
        {
            get;
            set;
        }
        /// <summary>
        /// 酒店ID
        /// </summary>
        public int TPDHotelId
        {
            get;
            set;
        }
        /// <summary>
        /// 房型ID
        /// </summary>
        public int TPDHRoomId
        {
            get;
            set;
        }
        /// <summary>
        /// 政策ID
        /// </summary>
        public int TPDHPolicyId
        {
            get;
            set;
        }

        #endregion

    }
}