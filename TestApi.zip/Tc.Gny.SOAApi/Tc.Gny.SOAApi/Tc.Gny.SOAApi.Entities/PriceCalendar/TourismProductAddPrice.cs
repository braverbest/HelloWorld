﻿using System;
using Tc.Gny.Framework.ORM.Attrbuites;
using Tc.Gny.Framework.ORM.Base;
using System.ComponentModel;

namespace Tc.Gny.SOAApi.Entities
{
    [Serializable]
    [Entity("TourismProductAddPrice")]
    public partial class TourismProductAddPrice : BaseEntity<TourismProductAddPrice>
    {
        public const string DBNAME = "TcTourismResource";


        #region	属性

        private int _tPAPId;

        /// <summary>
        /// 主键
        /// </summary>
        [Description("主键")]
        [PrimaryKey]
        [Identity]
        public int TPAPId
        {
            get
            {
                return this._tPAPId;
            }
            set
            {
                this.ChangeStack("TPAPId", value, this._tPAPId);
                this._tPAPId = value;
            }
        }


        private int _tPAPLineId;

        /// <summary>
        /// 线路id
        /// </summary>
        [Description("线路id")]
        public int TPAPLineId
        {
            get
            {
                return this._tPAPLineId;
            }
            set
            {
                this.ChangeStack("TPAPLineId", value, this._tPAPLineId);
                this._tPAPLineId = value;
            }
        }


        private decimal _tPAPPrice;

        /// <summary>
        /// 附加价格
        /// </summary>
        [Description("附加价格")]
        public decimal TPAPPrice
        {
            get
            {
                return this._tPAPPrice;
            }
            set
            {
                this.ChangeStack("TPAPPrice", value, this._tPAPPrice);
                this._tPAPPrice = value;
            }
        }


        private byte _tPAPFlag;

        /// <summary>
        /// 状态(0-无效,1-有效)
        /// </summary>
        [Description("状态(0-无效,1-有效)")]
        public byte TPAPFlag
        {
            get
            {
                return this._tPAPFlag;
            }
            set
            {
                this.ChangeStack("TPAPFlag", value, this._tPAPFlag);
                this._tPAPFlag = value;
            }
        }


        private int _tPAPUpdateId;

        /// <summary>
        /// 更新人id
        /// </summary>
        [Description("更新人id")]
        public int TPAPUpdateId
        {
            get
            {
                return this._tPAPUpdateId;
            }
            set
            {
                this.ChangeStack("TPAPUpdateId", value, this._tPAPUpdateId);
                this._tPAPUpdateId = value;
            }
        }


        private string _tPAPUpdateName;

        /// <summary>
        /// 更新人名称
        /// </summary>
        [Description("更新人名称")]
        public string TPAPUpdateName
        {
            get
            {
                return this._tPAPUpdateName;
            }
            set
            {
                this.ChangeStack("TPAPUpdateName", value, this._tPAPUpdateName);
                this._tPAPUpdateName = value;
            }
        }


        private DateTime _tPAPUpdateDate;

        /// <summary>
        /// 更新时间
        /// </summary>
        [Description("更新时间")]
        public DateTime TPAPUpdateDate
        {
            get
            {
                return this._tPAPUpdateDate;
            }
            set
            {
                this.ChangeStack("TPAPUpdateDate", value, this._tPAPUpdateDate);
                this._tPAPUpdateDate = value;
            }
        }


        #endregion
    }
}