﻿using System;
using Tc.Gny.Framework.ORM.Attrbuites;
using Tc.Gny.Framework.ORM.Base;

namespace Tc.Gny.SOAApi.Entities
{
    [Serializable]
    [Entity("CLine_LineResource")]
    public partial class CLineLineResource : BaseEntity<CLineLineResource>
    {

        #region	属性

        private int _id;

        /// <summary>
        /// Id
        /// </summary>
        [PrimaryKey]
        [Identity]
        public int Id
        {
            get
            {
                return this._id;
            }
            set
            {
                this.ChangeStack("Id", value, this._id);
                this._id = value;
            }
        }


        private string _serialid;

        /// <summary>
        /// Serialid
        /// </summary>
        public string Serialid
        {
            get
            {
                return this._serialid;
            }
            set
            {
                this.ChangeStack("Serialid", value, this._serialid);
                this._serialid = value;
            }
        }


        private int? _lhy_GroupId;

        /// <summary>
        /// Lhy_GroupId
        /// </summary>
        public int? Lhy_GroupId
        {
            get
            {
                return this._lhy_GroupId;
            }
            set
            {
                this.ChangeStack("Lhy_GroupId", value, this._lhy_GroupId);
                this._lhy_GroupId = value;
            }
        }


        private string _lhy_Guid;

        /// <summary>
        /// Lhy_Guid
        /// </summary>
        public string Lhy_Guid
        {
            get
            {
                return this._lhy_Guid;
            }
            set
            {
                this.ChangeStack("Lhy_Guid", value, this._lhy_Guid);
                this._lhy_Guid = value;
            }
        }


        private int? _supplierId;

        /// <summary>
        /// SupplierId
        /// </summary>
        public int? SupplierId
        {
            get
            {
                return this._supplierId;
            }
            set
            {
                this.ChangeStack("SupplierId", value, this._supplierId);
                this._supplierId = value;
            }
        }


        private int? _merchantId;

        /// <summary>
        /// MerchantId
        /// </summary>
        public int? MerchantId
        {
            get
            {
                return this._merchantId;
            }
            set
            {
                this.ChangeStack("MerchantId", value, this._merchantId);
                this._merchantId = value;
            }
        }


        private int? _inputType;

        /// <summary>
        /// InputType
        /// </summary>
        public int? InputType
        {
            get
            {
                return this._inputType;
            }
            set
            {
                this.ChangeStack("InputType", value, this._inputType);
                this._inputType = value;
            }
        }


        private int? _linePayType;

        /// <summary>
        /// LinePayType
        /// </summary>
        public int? LinePayType
        {
            get
            {
                return this._linePayType;
            }
            set
            {
                this.ChangeStack("LinePayType", value, this._linePayType);
                this._linePayType = value;
            }
        }


        private string _title;

        /// <summary>
        /// Title
        /// </summary>
        public string Title
        {
            get
            {
                return this._title;
            }
            set
            {
                this.ChangeStack("Title", value, this._title);
                this._title = value;
            }
        }


        private int? _admountAdvice;

        /// <summary>
        /// AdmountAdvice
        /// </summary>
        public int? AdmountAdvice
        {
            get
            {
                return this._admountAdvice;
            }
            set
            {
                this.ChangeStack("AdmountAdvice", value, this._admountAdvice);
                this._admountAdvice = value;
            }
        }


        private int? _amountDirect;

        /// <summary>
        /// AmountDirect
        /// </summary>
        public int? AmountDirect
        {
            get
            {
                return this._amountDirect;
            }
            set
            {
                this.ChangeStack("AmountDirect", value, this._amountDirect);
                this._amountDirect = value;
            }
        }


        private int? _amountContract;

        /// <summary>
        /// AmountContract
        /// </summary>
        public int? AmountContract
        {
            get
            {
                return this._amountContract;
            }
            set
            {
                this.ChangeStack("AmountContract", value, this._amountContract);
                this._amountContract = value;
            }
        }


        private string _mainTitle;

        /// <summary>
        /// MainTitle
        /// </summary>
        public string MainTitle
        {
            get
            {
                return this._mainTitle;
            }
            set
            {
                this.ChangeStack("MainTitle", value, this._mainTitle);
                this._mainTitle = value;
            }
        }


        private string _subTitle;

        /// <summary>
        /// SubTitle
        /// </summary>
        public string SubTitle
        {
            get
            {
                return this._subTitle;
            }
            set
            {
                this.ChangeStack("SubTitle", value, this._subTitle);
                this._subTitle = value;
            }
        }


        private string _showTitle;

        /// <summary>
        /// ShowTitle
        /// </summary>
        public string ShowTitle
        {
            get
            {
                return this._showTitle;
            }
            set
            {
                this.ChangeStack("ShowTitle", value, this._showTitle);
                this._showTitle = value;
            }
        }


        private int? _lineType;

        /// <summary>
        /// LineType
        /// </summary>
        public int? LineType
        {
            get
            {
                return this._lineType;
            }
            set
            {
                this.ChangeStack("LineType", value, this._lineType);
                this._lineType = value;
            }
        }


        private string _departureCity;

        /// <summary>
        /// DepartureCity
        /// </summary>
        public string DepartureCity
        {
            get
            {
                return this._departureCity;
            }
            set
            {
                this.ChangeStack("DepartureCity", value, this._departureCity);
                this._departureCity = value;
            }
        }


        private string _departureCityId;

        /// <summary>
        /// DepartureCityId
        /// </summary>
        public string DepartureCityId
        {
            get
            {
                return this._departureCityId;
            }
            set
            {
                this.ChangeStack("DepartureCityId", value, this._departureCityId);
                this._departureCityId = value;
            }
        }


        private string _destinationCity;

        /// <summary>
        /// DestinationCity
        /// </summary>
        public string DestinationCity
        {
            get
            {
                return this._destinationCity;
            }
            set
            {
                this.ChangeStack("DestinationCity", value, this._destinationCity);
                this._destinationCity = value;
            }
        }


        private string _destinationCityId;

        /// <summary>
        /// DestinationCityId
        /// </summary>
        public string DestinationCityId
        {
            get
            {
                return this._destinationCityId;
            }
            set
            {
                this.ChangeStack("DestinationCityId", value, this._destinationCityId);
                this._destinationCityId = value;
            }
        }


        private string _departureInfo;

        /// <summary>
        /// DepartureInfo
        /// </summary>
        public string DepartureInfo
        {
            get
            {
                return this._departureInfo;
            }
            set
            {
                this.ChangeStack("DepartureInfo", value, this._departureInfo);
                this._departureInfo = value;
            }
        }


        private string _createType;

        /// <summary>
        /// CreateType
        /// </summary>
        public string CreateType
        {
            get
            {
                return this._createType;
            }
            set
            {
                this.ChangeStack("CreateType", value, this._createType);
                this._createType = value;
            }
        }


        private string _createTypeValue;

        /// <summary>
        /// CreateTypeValue
        /// </summary>
        public string CreateTypeValue
        {
            get
            {
                return this._createTypeValue;
            }
            set
            {
                this.ChangeStack("CreateTypeValue", value, this._createTypeValue);
                this._createTypeValue = value;
            }
        }


        private string _createTypeDes;

        /// <summary>
        /// CreateTypeDes
        /// </summary>
        public string CreateTypeDes
        {
            get
            {
                return this._createTypeDes;
            }
            set
            {
                this.ChangeStack("CreateTypeDes", value, this._createTypeDes);
                this._createTypeDes = value;
            }
        }


        private int? _days;

        /// <summary>
        /// Days
        /// </summary>
        public int? Days
        {
            get
            {
                return this._days;
            }
            set
            {
                this.ChangeStack("Days", value, this._days);
                this._days = value;
            }
        }


        private DateTime? _createDate;

        /// <summary>
        /// CreateDate
        /// </summary>
        public DateTime? CreateDate
        {
            get
            {
                return this._createDate;
            }
            set
            {
                this.ChangeStack("CreateDate", value, this._createDate);
                this._createDate = value;
            }
        }


        private int? _dataFlag;

        /// <summary>
        /// DataFlag
        /// </summary>
        public int? DataFlag
        {
            get
            {
                return this._dataFlag;
            }
            set
            {
                this.ChangeStack("DataFlag", value, this._dataFlag);
                this._dataFlag = value;
            }
        }


        private DateTime? _startDate;

        /// <summary>
        /// StartDate
        /// </summary>
        public DateTime? StartDate
        {
            get
            {
                return this._startDate;
            }
            set
            {
                this.ChangeStack("StartDate", value, this._startDate);
                this._startDate = value;
            }
        }


        private DateTime? _endDate;

        /// <summary>
        /// EndDate
        /// </summary>
        public DateTime? EndDate
        {
            get
            {
                return this._endDate;
            }
            set
            {
                this.ChangeStack("EndDate", value, this._endDate);
                this._endDate = value;
            }
        }


        private string _imagePath;

        /// <summary>
        /// ImagePath
        /// </summary>
        public string ImagePath
        {
            get
            {
                return this._imagePath;
            }
            set
            {
                this.ChangeStack("ImagePath", value, this._imagePath);
                this._imagePath = value;
            }
        }


        private string _transport;

        /// <summary>
        /// Transport
        /// </summary>
        public string Transport
        {
            get
            {
                return this._transport;
            }
            set
            {
                this.ChangeStack("Transport", value, this._transport);
                this._transport = value;
            }
        }


        private int? _isRecommend;

        /// <summary>
        /// IsRecommend
        /// </summary>
        public int? IsRecommend
        {
            get
            {
                return this._isRecommend;
            }
            set
            {
                this.ChangeStack("IsRecommend", value, this._isRecommend);
                this._isRecommend = value;
            }
        }


        private int? _isDateStrategy;

        /// <summary>
        /// IsDateStrategy
        /// </summary>
        public int? IsDateStrategy
        {
            get
            {
                return this._isDateStrategy;
            }
            set
            {
                this.ChangeStack("IsDateStrategy", value, this._isDateStrategy);
                this._isDateStrategy = value;
            }
        }


        private int? _isHot;

        /// <summary>
        /// IsHot
        /// </summary>
        public int? IsHot
        {
            get
            {
                return this._isHot;
            }
            set
            {
                this.ChangeStack("IsHot", value, this._isHot);
                this._isHot = value;
            }
        }


        private int? _lineProperty;

        /// <summary>
        /// LineProperty
        /// </summary>
        public int? LineProperty
        {
            get
            {
                return this._lineProperty;
            }
            set
            {
                this.ChangeStack("LineProperty", value, this._lineProperty);
                this._lineProperty = value;
            }
        }


        private int? _categoryPPId;

        /// <summary>
        /// CategoryPPId
        /// </summary>
        public int? CategoryPPId
        {
            get
            {
                return this._categoryPPId;
            }
            set
            {
                this.ChangeStack("CategoryPPId", value, this._categoryPPId);
                this._categoryPPId = value;
            }
        }


        private string _uptAccount;

        /// <summary>
        /// UptAccount
        /// </summary>
        public string UptAccount
        {
            get
            {
                return this._uptAccount;
            }
            set
            {
                this.ChangeStack("UptAccount", value, this._uptAccount);
                this._uptAccount = value;
            }
        }


        private DateTime _uptDate;

        /// <summary>
        /// UptDate
        /// </summary>
        public DateTime UptDate
        {
            get
            {
                return this._uptDate;
            }
            set
            {
                this.ChangeStack("UptDate", value, this._uptDate);
                this._uptDate = value;
            }
        }


        private int _advanceDay;

        /// <summary>
        /// AdvanceDay
        /// </summary>
        public int AdvanceDay
        {
            get
            {
                return this._advanceDay;
            }
            set
            {
                this.ChangeStack("AdvanceDay", value, this._advanceDay);
                this._advanceDay = value;
            }
        }


        private string _createAccount;

        /// <summary>
        /// CreateAccount
        /// </summary>
        public string CreateAccount
        {
            get
            {
                return this._createAccount;
            }
            set
            {
                this.ChangeStack("CreateAccount", value, this._createAccount);
                this._createAccount = value;
            }
        }


        private int _lineAttribute;

        /// <summary>
        /// LineAttribute
        /// </summary>
        public int LineAttribute
        {
            get
            {
                return this._lineAttribute;
            }
            set
            {
                this.ChangeStack("LineAttribute", value, this._lineAttribute);
                this._lineAttribute = value;
            }
        }


        private string _remark;

        /// <summary>
        /// Remark
        /// </summary>
        public string Remark
        {
            get
            {
                return this._remark;
            }
            set
            {
                this.ChangeStack("Remark", value, this._remark);
                this._remark = value;
            }
        }


        private int _isOO;

        /// <summary>
        /// IsOO
        /// </summary>
        public int IsOO
        {
            get
            {
                return this._isOO;
            }
            set
            {
                this.ChangeStack("IsOO", value, this._isOO);
                this._isOO = value;
            }
        }


        private byte _isRoutine;

        /// <summary>
        /// IsRoutine
        /// </summary>
        public byte IsRoutine
        {
            get
            {
                return this._isRoutine;
            }
            set
            {
                this.ChangeStack("IsRoutine", value, this._isRoutine);
                this._isRoutine = value;
            }
        }


        private int _theVersion;

        /// <summary>
        /// TheVersion
        /// </summary>
        public int TheVersion
        {
            get
            {
                return this._theVersion;
            }
            set
            {
                this.ChangeStack("TheVersion", value, this._theVersion);
                this._theVersion = value;
            }
        }


        private int _travelId;

        /// <summary>
        /// TravelId
        /// </summary>
        public int TravelId
        {
            get
            {
                return this._travelId;
            }
            set
            {
                this.ChangeStack("TravelId", value, this._travelId);
                this._travelId = value;
            }
        }


        private int _specialTypeId;

        /// <summary>
        /// SpecialTypeId
        /// </summary>
        public int SpecialTypeId
        {
            get
            {
                return this._specialTypeId;
            }
            set
            {
                this.ChangeStack("SpecialTypeId", value, this._specialTypeId);
                this._specialTypeId = value;
            }
        }


        private int _referLineId;

        /// <summary>
        /// ReferLineId
        /// </summary>
        public int ReferLineId
        {
            get
            {
                return this._referLineId;
            }
            set
            {
                this.ChangeStack("ReferLineId", value, this._referLineId);
                this._referLineId = value;
            }
        }


        private int _cLRHolidayCrawlLine;

        /// <summary>
        /// CLRHolidayCrawlLine
        /// </summary>
        public int CLRHolidayCrawlLine
        {
            get
            {
                return this._cLRHolidayCrawlLine;
            }
            set
            {
                this.ChangeStack("CLRHolidayCrawlLine", value, this._cLRHolidayCrawlLine);
                this._cLRHolidayCrawlLine = value;
            }
        }


        private int _cLRHolidayCrawlLineType;

        /// <summary>
        /// CLRHolidayCrawlLineType
        /// </summary>
        public int CLRHolidayCrawlLineType
        {
            get
            {
                return this._cLRHolidayCrawlLineType;
            }
            set
            {
                this.ChangeStack("CLRHolidayCrawlLineType", value, this._cLRHolidayCrawlLineType);
                this._cLRHolidayCrawlLineType = value;
            }
        }


        private byte _cLRLineResourceType;

        /// <summary>
        /// CLRLineResourceType
        /// </summary>
        public byte CLRLineResourceType
        {
            get
            {
                return this._cLRLineResourceType;
            }
            set
            {
                this.ChangeStack("CLRLineResourceType", value, this._cLRLineResourceType);
                this._cLRLineResourceType = value;
            }
        }


        private string _cLRRecomImagePath;

        /// <summary>
        /// CLRRecomImagePath
        /// </summary>
        public string CLRRecomImagePath
        {
            get
            {
                return this._cLRRecomImagePath;
            }
            set
            {
                this.ChangeStack("CLRRecomImagePath", value, this._cLRRecomImagePath);
                this._cLRRecomImagePath = value;
            }
        }


        private byte _cLRIsDel;

        /// <summary>
        /// CLRIsDel
        /// </summary>
        public byte CLRIsDel
        {
            get
            {
                return this._cLRIsDel;
            }
            set
            {
                this.ChangeStack("CLRIsDel", value, this._cLRIsDel);
                this._cLRIsDel = value;
            }
        }


        private byte _cLRIsCoupon;

        /// <summary>
        /// CLRIsCoupon
        /// </summary>
        public byte CLRIsCoupon
        {
            get
            {
                return this._cLRIsCoupon;
            }
            set
            {
                this.ChangeStack("CLRIsCoupon", value, this._cLRIsCoupon);
                this._cLRIsCoupon = value;
            }
        }


        private byte _cLRIsEmphasis;

        /// <summary>
        /// CLRIsEmphasis
        /// </summary>
        public byte CLRIsEmphasis
        {
            get
            {
                return this._cLRIsEmphasis;
            }
            set
            {
                this.ChangeStack("CLRIsEmphasis", value, this._cLRIsEmphasis);
                this._cLRIsEmphasis = value;
            }
        }


        private byte _cLRImageType;

        /// <summary>
        /// CLRImageType
        /// </summary>
        public byte CLRImageType
        {
            get
            {
                return this._cLRImageType;
            }
            set
            {
                this.ChangeStack("CLRImageType", value, this._cLRImageType);
                this._cLRImageType = value;
            }
        }


        private byte _cLRIsTaobao;

        /// <summary>
        /// CLRIsTaobao
        /// </summary>
        public byte CLRIsTaobao
        {
            get
            {
                return this._cLRIsTaobao;
            }
            set
            {
                this.ChangeStack("CLRIsTaobao", value, this._cLRIsTaobao);
                this._cLRIsTaobao = value;
            }
        }


        private int _cLRCSTId;

        /// <summary>
        /// CLRCSTId
        /// </summary>
        public int CLRCSTId
        {
            get
            {
                return this._cLRCSTId;
            }
            set
            {
                this.ChangeStack("CLRCSTId", value, this._cLRCSTId);
                this._cLRCSTId = value;
            }
        }


        private byte _cLRIsCodes;

        /// <summary>
        /// 是否为Ebooking产品(0-非Ebooking产品,1-Ebooking产品)
        /// </summary>
        public byte CLRIsCodes
        {
            get
            {
                return this._cLRIsCodes;
            }
            set
            {
                this.ChangeStack("CLRIsCodes", value, this._cLRIsCodes);
                this._cLRIsCodes = value;
            }
        }


        private byte _cLRIsHard;

        /// <summary>
        /// CLRIsHard
        /// </summary>
        public byte CLRIsHard
        {
            get
            {
                return this._cLRIsHard;
            }
            set
            {
                this.ChangeStack("CLRIsHard", value, this._cLRIsHard);
                this._cLRIsHard = value;
            }
        }


        private byte _cLRIsMuchSupper;

        /// <summary>
        /// CLRIsMuchSupper
        /// </summary>
        public byte CLRIsMuchSupper
        {
            get
            {
                return this._cLRIsMuchSupper;
            }
            set
            {
                this.ChangeStack("CLRIsMuchSupper", value, this._cLRIsMuchSupper);
                this._cLRIsMuchSupper = value;
            }
        }


        private byte _cLRUserAdvanceDay;

        /// <summary>
        /// CLRUserAdvanceDay
        /// </summary>
        public byte CLRUserAdvanceDay
        {
            get
            {
                return this._cLRUserAdvanceDay;
            }
            set
            {
                this.ChangeStack("CLRUserAdvanceDay", value, this._cLRUserAdvanceDay);
                this._cLRUserAdvanceDay = value;
            }
        }


        private int _cLRUserAdvanceDayType;

        /// <summary>
        /// CLRUserAdvanceDayType
        /// </summary>
        public int CLRUserAdvanceDayType
        {
            get
            {
                return this._cLRUserAdvanceDayType;
            }
            set
            {
                this.ChangeStack("CLRUserAdvanceDayType", value, this._cLRUserAdvanceDayType);
                this._cLRUserAdvanceDayType = value;
            }
        }


        private DateTime _cLRMaxEndDate;

        /// <summary>
        /// CLRMaxEndDate
        /// </summary>
        public DateTime CLRMaxEndDate
        {
            get
            {
                return this._cLRMaxEndDate;
            }
            set
            {
                this.ChangeStack("CLRMaxEndDate", value, this._cLRMaxEndDate);
                this._cLRMaxEndDate = value;
            }
        }


        private byte _cLRIsInvoking;

        /// <summary>
        /// CLRIsInvoking
        /// </summary>
        public byte CLRIsInvoking
        {
            get
            {
                return this._cLRIsInvoking;
            }
            set
            {
                this.ChangeStack("CLRIsInvoking", value, this._cLRIsInvoking);
                this._cLRIsInvoking = value;
            }
        }


        private int _cLRCruisesCompanyId;

        /// <summary>
        /// CLRCruisesCompanyId
        /// </summary>
        public int CLRCruisesCompanyId
        {
            get
            {
                return this._cLRCruisesCompanyId;
            }
            set
            {
                this.ChangeStack("CLRCruisesCompanyId", value, this._cLRCruisesCompanyId);
                this._cLRCruisesCompanyId = value;
            }
        }


        private int _cLRCruisesShipId;

        /// <summary>
        /// CLRCruisesShipId
        /// </summary>
        public int CLRCruisesShipId
        {
            get
            {
                return this._cLRCruisesShipId;
            }
            set
            {
                this.ChangeStack("CLRCruisesShipId", value, this._cLRCruisesShipId);
                this._cLRCruisesShipId = value;
            }
        }


        private int _cLRAirRouteId;

        /// <summary>
        /// CLRAirRouteId
        /// </summary>
        public int CLRAirRouteId
        {
            get
            {
                return this._cLRAirRouteId;
            }
            set
            {
                this.ChangeStack("CLRAirRouteId", value, this._cLRAirRouteId);
                this._cLRAirRouteId = value;
            }
        }


        private int _cLRPortId;

        /// <summary>
        /// CLRPortId
        /// </summary>
        public int CLRPortId
        {
            get
            {
                return this._cLRPortId;
            }
            set
            {
                this.ChangeStack("CLRPortId", value, this._cLRPortId);
                this._cLRPortId = value;
            }
        }


        private byte _cLRIsCallOut;

        /// <summary>
        /// CLRIsCallOut
        /// </summary>
        public byte CLRIsCallOut
        {
            get
            {
                return this._cLRIsCallOut;
            }
            set
            {
                this.ChangeStack("CLRIsCallOut", value, this._cLRIsCallOut);
                this._cLRIsCallOut = value;
            }
        }


        private int _cLRProjectType;

        /// <summary>
        /// CLRProjectType
        /// </summary>
        public int CLRProjectType
        {
            get
            {
                return this._cLRProjectType;
            }
            set
            {
                this.ChangeStack("CLRProjectType", value, this._cLRProjectType);
                this._cLRProjectType = value;
            }
        }


        private DateTime _cLRMinAmounDate;

        /// <summary>
        /// CLRMinAmounDate
        /// </summary>
        public DateTime CLRMinAmounDate
        {
            get
            {
                return this._cLRMinAmounDate;
            }
            set
            {
                this.ChangeStack("CLRMinAmounDate", value, this._cLRMinAmounDate);
                this._cLRMinAmounDate = value;
            }
        }


        private byte _cLRIsGroupBuy;

        /// <summary>
        /// CLRIsGroupBuy
        /// </summary>
        public byte CLRIsGroupBuy
        {
            get
            {
                return this._cLRIsGroupBuy;
            }
            set
            {
                this.ChangeStack("CLRIsGroupBuy", value, this._cLRIsGroupBuy);
                this._cLRIsGroupBuy = value;
            }
        }


        private DateTime _cLROffLineDateOfGroupBuy;

        /// <summary>
        /// CLROffLineDateOfGroupBuy
        /// </summary>
        public DateTime CLROffLineDateOfGroupBuy
        {
            get
            {
                return this._cLROffLineDateOfGroupBuy;
            }
            set
            {
                this.ChangeStack("CLROffLineDateOfGroupBuy", value, this._cLROffLineDateOfGroupBuy);
                this._cLROffLineDateOfGroupBuy = value;
            }
        }


        private int _cLRLeavePortCityId;

        /// <summary>
        /// CLRLeavePortCityId
        /// </summary>
        public int CLRLeavePortCityId
        {
            get
            {
                return this._cLRLeavePortCityId;
            }
            set
            {
                this.ChangeStack("CLRLeavePortCityId", value, this._cLRLeavePortCityId);
                this._cLRLeavePortCityId = value;
            }
        }


        private string _cLRLeavePortCity;

        /// <summary>
        /// CLRLeavePortCity
        /// </summary>
        public string CLRLeavePortCity
        {
            get
            {
                return this._cLRLeavePortCity;
            }
            set
            {
                this.ChangeStack("CLRLeavePortCity", value, this._cLRLeavePortCity);
                this._cLRLeavePortCity = value;
            }
        }


        private int _cLRCruiseDifference;

        /// <summary>
        /// CLRCruiseDifference
        /// </summary>
        public int CLRCruiseDifference
        {
            get
            {
                return this._cLRCruiseDifference;
            }
            set
            {
                this.ChangeStack("CLRCruiseDifference", value, this._cLRCruiseDifference);
                this._cLRCruiseDifference = value;
            }
        }


        private DateTime _cLRUpLineDateOfGroupBuy;

        /// <summary>
        /// CLRUpLineDateOfGroupBuy
        /// </summary>
        public DateTime CLRUpLineDateOfGroupBuy
        {
            get
            {
                return this._cLRUpLineDateOfGroupBuy;
            }
            set
            {
                this.ChangeStack("CLRUpLineDateOfGroupBuy", value, this._cLRUpLineDateOfGroupBuy);
                this._cLRUpLineDateOfGroupBuy = value;
            }
        }


        private string _cLRSailImagePath;

        /// <summary>
        /// CLRSailImagePath
        /// </summary>
        public string CLRSailImagePath
        {
            get
            {
                return this._cLRSailImagePath;
            }
            set
            {
                this.ChangeStack("CLRSailImagePath", value, this._cLRSailImagePath);
                this._cLRSailImagePath = value;
            }
        }


        private int _cLRReceivePortId;

        /// <summary>
        /// CLRReceivePortId
        /// </summary>
        public int CLRReceivePortId
        {
            get
            {
                return this._cLRReceivePortId;
            }
            set
            {
                this.ChangeStack("CLRReceivePortId", value, this._cLRReceivePortId);
                this._cLRReceivePortId = value;
            }
        }


        private string _cLRActTitle;

        /// <summary>
        /// CLRActTitle
        /// </summary>
        public string CLRActTitle
        {
            get
            {
                return this._cLRActTitle;
            }
            set
            {
                this.ChangeStack("CLRActTitle", value, this._cLRActTitle);
                this._cLRActTitle = value;
            }
        }


        private int _cLRProductTypeId;

        /// <summary>
        /// CLRProductTypeId
        /// </summary>
        public int CLRProductTypeId
        {
            get
            {
                return this._cLRProductTypeId;
            }
            set
            {
                this.ChangeStack("CLRProductTypeId", value, this._cLRProductTypeId);
                this._cLRProductTypeId = value;
            }
        }


        private int _cLROwnerPersonId;

        /// <summary>
        /// CLROwnerPersonId
        /// </summary>
        public int CLROwnerPersonId
        {
            get
            {
                return this._cLROwnerPersonId;
            }
            set
            {
                this.ChangeStack("CLROwnerPersonId", value, this._cLROwnerPersonId);
                this._cLROwnerPersonId = value;
            }
        }


        private string _cLROwnerPersonName;

        /// <summary>
        /// 线路归属人名(产品经理)
        /// </summary>
        public string CLROwnerPersonName
        {
            get
            {
                return this._cLROwnerPersonName;
            }
            set
            {
                this.ChangeStack("CLROwnerPersonName", value, this._cLROwnerPersonName);
                this._cLROwnerPersonName = value;
            }
        }


        private int _cLRSort;

        /// <summary>
        /// CLRSort
        /// </summary>
        public int CLRSort
        {
            get
            {
                return this._cLRSort;
            }
            set
            {
                this.ChangeStack("CLRSort", value, this._cLRSort);
                this._cLRSort = value;
            }
        }


        private string _nights;

        /// <summary>
        /// Nights
        /// </summary>
        public string Nights
        {
            get
            {
                return this._nights;
            }
            set
            {
                this.ChangeStack("Nights", value, this._nights);
                this._nights = value;
            }
        }


        private int _cLRStockFlag;

        /// <summary>
        /// CLRStockFlag
        /// </summary>
        public int CLRStockFlag
        {
            get
            {
                return this._cLRStockFlag;
            }
            set
            {
                this.ChangeStack("CLRStockFlag", value, this._cLRStockFlag);
                this._cLRStockFlag = value;
            }
        }


        private int _cLRTopSort;

        /// <summary>
        /// CLRTopSort
        /// </summary>
        public int CLRTopSort
        {
            get
            {
                return this._cLRTopSort;
            }
            set
            {
                this.ChangeStack("CLRTopSort", value, this._cLRTopSort);
                this._cLRTopSort = value;
            }
        }


        private decimal _cLRStockPercent;

        /// <summary>
        /// CLRStockPercent
        /// </summary>
        public decimal CLRStockPercent
        {
            get
            {
                return this._cLRStockPercent;
            }
            set
            {
                this.ChangeStack("CLRStockPercent", value, this._cLRStockPercent);
                this._cLRStockPercent = value;
            }
        }


        private decimal _cLRContentPercent;

        /// <summary>
        /// CLRContentPercent
        /// </summary>
        public decimal CLRContentPercent
        {
            get
            {
                return this._cLRContentPercent;
            }
            set
            {
                this.ChangeStack("CLRContentPercent", value, this._cLRContentPercent);
                this._cLRContentPercent = value;
            }
        }


        private decimal _cLRConvertPercent;

        /// <summary>
        /// CLRConvertPercent
        /// </summary>
        public decimal CLRConvertPercent
        {
            get
            {
                return this._cLRConvertPercent;
            }
            set
            {
                this.ChangeStack("CLRConvertPercent", value, this._cLRConvertPercent);
                this._cLRConvertPercent = value;
            }
        }


        private int _cLRProType;

        /// <summary>
        /// CLRProType
        /// </summary>
        public int CLRProType
        {
            get
            {
                return this._cLRProType;
            }
            set
            {
                this.ChangeStack("CLRProType", value, this._cLRProType);
                this._cLRProType = value;
            }
        }


        private int _payAdvanceDay;

        /// <summary>
        /// PayAdvanceDay
        /// </summary>
        public int PayAdvanceDay
        {
            get
            {
                return this._payAdvanceDay;
            }
            set
            {
                this.ChangeStack("PayAdvanceDay", value, this._payAdvanceDay);
                this._payAdvanceDay = value;
            }
        }


        private byte _cLRLineRouteVersion;

        /// <summary>
        /// CLRLineRouteVersion
        /// </summary>
        public byte CLRLineRouteVersion
        {
            get
            {
                return this._cLRLineRouteVersion;
            }
            set
            {
                this.ChangeStack("CLRLineRouteVersion", value, this._cLRLineRouteVersion);
                this._cLRLineRouteVersion = value;
            }
        }


        private string _cLRFlightPortCityId;

        /// <summary>
        /// CLRFlightPortCityId
        /// </summary>
        public string CLRFlightPortCityId
        {
            get
            {
                return this._cLRFlightPortCityId;
            }
            set
            {
                this.ChangeStack("CLRFlightPortCityId", value, this._cLRFlightPortCityId);
                this._cLRFlightPortCityId = value;
            }
        }


        private string _cLRFlightPortCity;

        /// <summary>
        /// CLRFlightPortCity
        /// </summary>
        public string CLRFlightPortCity
        {
            get
            {
                return this._cLRFlightPortCity;
            }
            set
            {
                this.ChangeStack("CLRFlightPortCity", value, this._cLRFlightPortCity);
                this._cLRFlightPortCity = value;
            }
        }


        private int _cLRODTopSort;

        /// <summary>
        /// OD线路置顶排序数字
        /// </summary>
        public int CLRODTopSort
        {
            get
            {
                return this._cLRODTopSort;
            }
            set
            {
                this.ChangeStack("CLRODTopSort", value, this._cLRODTopSort);
                this._cLRODTopSort = value;
            }
        }


        private byte _cLRProfitType;

        /// <summary>
        /// 营利类型：0：非自营，1：自营
        /// </summary>
        public byte CLRProfitType
        {
            get
            {
                return this._cLRProfitType;
            }
            set
            {
                this.ChangeStack("CLRProfitType", value, this._cLRProfitType);
                this._cLRProfitType = value;
            }
        }


        private int _cLRCompany;

        /// <summary>
        /// 所属公司：1：同程国际旅行社有限公司，2：同程上海分公司
        /// </summary>
        public int CLRCompany
        {
            get
            {
                return this._cLRCompany;
            }
            set
            {
                this.ChangeStack("CLRCompany", value, this._cLRCompany);
                this._cLRCompany = value;
            }
        }


        #endregion
    }

}