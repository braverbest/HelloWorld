﻿
namespace Tc.Gny.SOAApi.Entities
{
    /// <summary>
    /// 数据库管理类
    /// </summary>
    public class DatabaseConnection
    {
        /// <summary>
        /// TcTourismResource
        /// </summary>
        public const string Db_TcTourismResource = "TcTourismResource";

        /// <summary>
        /// TcTourism
        /// </summary>
        public const string Db_TcTourism = "TcTourism";

        /// <summary>
        /// TcTourismLog
        /// </summary>
        public const string Db_TcTourismLog = "TcTourismLog";

        /// <summary>
        /// TcTourismOrder
        /// </summary>
        public const string Db_TcTourismOrder = "TcTourismOrder";

        /// <summary>
        /// TcTourismCommunal
        /// </summary>
        public const string Db_TcTourismCommunal = "TcTourismCommunal";

        /// <summary>
        /// 17uSMS_Receive
        /// </summary>
        public const string Db_17uSMS_Receive = "17uSMS_Receive";

        /// <summary>
        /// TcTourismEBooking
        /// </summary>
        public const string Db_TcTourismEBooking = "TcTourismEBooking";


        /// <summary>
        /// TCTourismCampaign
        /// </summary>
        public const string Db_TcTourismCampaign = "TCTourismCampaign";
        /// <summary>
        /// TCTourismData
        /// </summary>
        public const string Db_TCTourismData = "TCTourismData";

        /// <summary>
        /// TCTourismEOrder
        /// </summary>
        public const string Db_TCTourismEOrder = "TCTourismEOrder";

        /// <summary>
        /// TCTourismEOrderLog
        /// </summary>
        public const string Db_TCTourismEOrderLog = "TCTourismEOrderLog";
        /// <summary>
        /// TCTourismBI
        /// </summary>
        public const string TCTourismBI = "TCTourismBI";

    }
}
