﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tc.Gny.Framework.ORM.Core;
using Tc.Gny.Framework.ORM.Implementation;
using Tc.Gny.Framework.ORM.Interface;

namespace Tc.Gny.SOAApi.Entities
{
    /// <summary>
    /// 数据操作上下文
    /// </summary>
    public class DbContext : DBContextBase
    {
        public DbContext()
            : base()
        {
        }

        public DbContext(string connectionString)
            : base(connectionString)
        {

        }

        public DbContext(DBOperationType dbType, string dbName)
            : base(dbType, dbName)
        {

        }
    }
}