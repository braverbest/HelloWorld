﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tc.Gny.SOAApi.Entities.EOrder;
using Tc.Gny.SOAApi.Entities.EOrder.Order;
using Tc.Gny.SOAApi.EOrder.DaoCore;

namespace Tc.Gny.SOAApi.EOrder.OrderImpl
{
    /// <summary>
    /// 订单接口实现类
    /// </summary>
    /// { Created At Time:[ 2016/3/25 10:01 ], By User:wcj21259, On Machine:WCJ }
    public class OrderDaoImpl : Share
    {
        /// <summary>
        /// 测试代码.
        /// </summary>
        /// <returns></returns>
        /// { Created At Time:[ 2016/3/29 10:55 ], By User:wcj21259, On Machine:WCJ }
        public List<string> GetList()
        {
            return new List<string>() { "1", "2", "3", "4" };
        }

        /// <summary>
        /// 根据订单流水号获取订单列表.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <returns></returns>
        /// { Created At Time:[ 2016/3/29 14:25 ], By User:wcj21259, On Machine:WCJ }
        public BasePageList<CLineOrderViewModel> GetCLineOrderList(CLineOrderQueryModel entity)
        {
            // sql
            string sql = @"select co.id,co.SalesPrice,co.OrderDate,co.OrderFlag,cd.LineTitle from CLineOrder as co with(nolock) 
                            inner join CLineOrderDetail as cd with(nolock) on co.serialid = cd.OrderSerialid
                            where co.MemberId=@MemberId";

            CLineOrderQueryModel queryModel = new CLineOrderQueryModel() { MemberId = entity.MemberId };

            if (!string.IsNullOrEmpty(entity.OrderFlag))
            {
                sql += " and OrderFlag = @OrderFlag ";
                queryModel.OrderFlag = entity.OrderFlag;
            }

            entity.Order = string.IsNullOrEmpty(entity.Order) ? "id desc" : entity.Order;

            PagingModel model = new PagingModel(sql, "*", entity.Order, queryModel, entity.PageSize, entity.PageIndex);
            return ExecutePaging<CLineOrderViewModel>(model, DbName.TCTourismEOrder);
        }
    }
}
