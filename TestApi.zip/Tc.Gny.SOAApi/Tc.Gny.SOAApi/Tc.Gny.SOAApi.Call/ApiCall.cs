﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using Tc.Gny.Framework.Core.Common;
using Tc.Gny.Framework.Core.Json;

namespace Tc.Gny.SOAApi.Call
{
    public static class ApiCall
    {
        /// <summary>
        /// 调用API方法--无加密
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public static ApiResult Call(string api, string method, params KeyValuePair<string, object>[] paras)
        {
            WebClient wc = new WebClient();
            wc.Encoding = Encoding.UTF8;
            wc.Headers.Add("Content-Type", "application/x-www-form-urlencoded");
            StringBuilder sbpara = new StringBuilder();
            foreach (var p in paras)
            {
                sbpara.Append(p.Key + "=" + p.Value + "&");
            }

            var para = sbpara.ToString().TrimEnd('&');
            var data = wc.UploadString(Cfg.GetAppStr("soaurl") + api + "/" + method + "/", "post", para);
            return JsonHelper.DeserializeObject<ApiResult>(data);
        }

        /// <summary>
        /// 调用API方法--有加密
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public static ApiResult CallAuth(string api, string method, params KeyValuePair<string, object>[] paras)
        {
            WebClient wc = new WebClient();
            wc.Encoding = Encoding.UTF8;
            wc.Headers.Add("Content-Type", "application/x-www-form-urlencoded");
            StringBuilder sbpara = new StringBuilder();
            var parastr = "";
            foreach (var p in paras)
            {
                sbpara.Append(p.Key + "=" + p.Value + "&");
                parastr += p.Value;
            }

            var cfg = CallCfg.Instance.CallCfgs.FirstOrDefault();
            if (cfg == null)
            {
                throw new Exception("没有添加配置");
            }


            var token = Tc.Gny.Framework.Core.Security.Encypt.MD5(api.ToLower() + method.ToLower()+parastr + cfg.AppKey);
            var para = sbpara.ToString().TrimEnd('&');
            var data = wc.UploadString(Cfg.GetAppStr("soaurl") + api + "/" + method + "/" + "?appid=" + cfg.AppId + "&token=" + token, "post", para);
            return JsonHelper.DeserializeObject<ApiResult>(data);
        }
    }


    public enum ResultCode
    {
        //成功
        Success = 200,
        //没找到api
        NotFoundApi = 404,
        //没找到方法
        NotFoundMehtod = 403,
        //报错
        Error = 500,
        //没有权限
        NoRights = 405,
    }

    public class ApiResult
    {
        /// <summary>
        /// 返回编码
        /// </summary>
        public ResultCode ResultCode { get; set; }

        /// <summary>
        /// 返回结果
        /// </summary>
        public object ResultBody { get; set; }

        /// <summary>
        /// 异常信息
        /// </summary>
        public string Exception { get; set; }
    }

}