﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Linq;
using Tc.Gny.Framework.Core.Common;

namespace Tc.Gny.SOAApi.Call
{
    public class CallCfg : SingleTon<CallCfg>
    {
        public List< CfgModel> CallCfgs;

        public CallCfg()
        {
            XDocument doc = null;
            if (HttpContext.Current == null)
            {
                doc = XDocument.Load(AppDomain.CurrentDomain.BaseDirectory+ "/App_Data/cfg/cfg.xml");
            }
            else
            {
                doc = XDocument.Load(HttpContext.Current.Server.MapPath("/App_Data/cfg/cfg.xml"));
            }
             
            var list = doc.Descendants("app").Select(p => new CfgModel()
            {
                AppId = (string)p.Element("appid"),
                AppKey = (string)p.Element("appkey")
            });
            CallCfgs = list.ToList();
        }
    }

    public class CfgModel
    {
        /// <summary>
        /// 调用方id
        /// </summary>
        public string AppId { get; set; }

        /// <summary>
        /// 调用方名称
        /// </summary>
        public string AppKey { get; set; }
    }
}
