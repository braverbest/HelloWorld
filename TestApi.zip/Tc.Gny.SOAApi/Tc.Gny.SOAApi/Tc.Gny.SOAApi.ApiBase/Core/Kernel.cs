﻿/*
 陈老师开源奉献--具体技术学习可阅读asp.net mvc4 源代码
 */
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using NPOI.SS.Formula.Functions;
using Tc.Gny.SOAApi.ApiBase.Api;
using Tc.Gny.SOAApi.ApiBase.Args;
using Tc.Gny.SOAApi.ApiBase.Base;
using Tc.Gny.SOAApi.ApiBase.Fliter;
using Tc.Gny.SOAApi.ApiBase.Result;

namespace Tc.Gny.SOAApi.ApiBase.Core
{
    public class Kernel
    {
        private ConcurrentDictionary<string, ApiLgc> _apiTypes;

        public Kernel()
        {
            _apiTypes = new ConcurrentDictionary<string, ApiLgc>();
        }

        internal bool Contains(string name)
        {
            return _apiTypes.ContainsKey(name);
        }

        internal void Add(BaseApi api, Type type, string apiname, string desc)
        {
            ApiLgc lgc = new ApiLgc();
            lgc.ApiName = apiname;
            lgc.Desc = desc;
            lgc.ApiType = type;
            lgc.ApiMethods = new Dictionary<string, ApiMethod>();
            lgc.ApiInstance = api;
            var mtds = type.GetMethods(BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Public);
            foreach (var methodInfo in mtds)
            {
                var name = methodInfo.Name.ToLower();
                if (methodInfo.ToString().Contains("System.EventHandler"))
                {
                    continue;
                }
                
                if (lgc.ApiMethods.ContainsKey(name))
                {
                    throw new Exception("已经包含了该方法的API定义，请重命名,API类型【" + apiname + "】");
                }
                var mdesc = methodInfo.GetCustomAttributes().GetDesc();
                var apifilter = methodInfo.GetCustomAttributes().GetApiFilter();
                var authfilter = methodInfo.GetCustomAttributes().GetAuthfilter();
                lgc.ApiMethods.Add(name, new ApiMethod()
                {
                    FullName = methodInfo.ToString(),
                    Desc = mdesc,
                    MethodName = name,
                    ParameterInfos = methodInfo.GetParameters().ToList(),
                    Dispatcher = new ActionMethodDispatcher(methodInfo),
                    ApiFilter = apifilter,
                    AuthFilter = authfilter
                });

            }

            _apiTypes.TryAdd(lgc.ApiName, lgc);
        }

        /// <summary>
        /// 获取API对象
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="name"></param>
        /// <returns></returns>
        public T GetApi<T>(string name) where T : BaseApi
        {
            if (_apiTypes.ContainsKey(name.ToLower()))
            {
                return (T)_apiTypes[name.ToLower()].ApiInstance;
            }
            return null;
        }

        internal ApiResult Exec(string name, string method, HttpRequestBase request)
        {
            var api = _apiTypes[name];
            if (!api.ApiMethods.ContainsKey(method))
            {
                throw new Exception("在API【" + name + "】中未找到api方法" + method);
            }

            var func = api.ApiMethods[method];
            var apiFilter = func.ApiFilter;
            var authfilter = func.AuthFilter;
            var objs = ParameterHelper.GenParas(func.ParameterInfos, request);
            ApiExecFactory.OnOnApiExecuting(new ApiExecutingEventArgs(name, method, request));
            //验证
            if (authfilter != null)
            {
                AuthContext authContext = new AuthContext()
                {
                    ApiInstance = api.ApiInstance,
                    ApiName = name,
                    MethodName = method,
                    Request = request
                };
                authfilter.OnAuth(authContext);
                if (authContext.Result != null && authContext.Result.ResultCode != ResultCode.Success)
                {
                    //失败了
                    ApiExecFactory.OnOnApiExecutedError(new ApiExecutedErrorEventArgs(name, method, request, authContext.Result, null));
                    return authContext.Result;
                }
            }

            //执行前
            if (apiFilter != null)
            {
                ApiExecutingContext extingctx = new ApiExecutingContext()
                {
                    ApiInstance = api.ApiInstance,
                    ApiName = name,
                    MethodName = method,
                    Paras = objs,
                    Request = request
                };
                apiFilter.OnApiExecuting(extingctx);
                if (extingctx.Result != null && extingctx.Result.ResultCode != ResultCode.Success)
                {
                    ApiExecFactory.OnOnApiExecutedError(new ApiExecutedErrorEventArgs(name, method, request, extingctx.Result, null));
                    return extingctx.Result;
                }
            }
            var ret = new ApiResult()
                {
                    ResultCode = ResultCode.Success

                };
            //执行中
            try
            {
                var v = func.Dispatcher.Execute(api.ApiInstance, objs);
                ret.ResultBody = v;
            }
            catch (Exception ex)
            {
                api.ApiInstance.RaiseError(ex);
                ret.ResultCode = ResultCode.Error;
                ret.Exception = ex.Message;
                ApiExecFactory.OnOnApiExecutedError(new ApiExecutedErrorEventArgs(name, method, request, ret, ex));
                return ret;
            }
            finally
            {
                //执行后
                if (apiFilter != null)
                {
                    ApiExecutedContext extdctx = new ApiExecutedContext()
                    {
                        ApiInstance = api.ApiInstance,
                        ApiName = name,
                        MethodName = method,
                        Response = HttpContext.Current.Response,
                        Result = ret
                    };
                    apiFilter.OnApiExecuted(extdctx);
                }
            }
            if (ret.ResultCode == ResultCode.Success)
            {
                ApiExecFactory.OnOnApiExecutedSuccess(new ApiExecutedSuccessEventArgs(name, method, request, ret));
            }
            else
            {
                ApiExecFactory.OnOnApiExecutedError(new ApiExecutedErrorEventArgs(name, method, request, ret, null));
            }
            return ret;
        }

        public List<ApiLgc> GetAllLgc()
        {
            return _apiTypes.Values.ToList();
        }


    }
}
