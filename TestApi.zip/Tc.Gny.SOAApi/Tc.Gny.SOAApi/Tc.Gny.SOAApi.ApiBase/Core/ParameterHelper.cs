﻿/*
 陈老师开源奉献--具体技术学习可阅读asp.net mvc4 源代码
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using Newtonsoft.Json;
using Tc.Gny.Framework.Core.Common;

namespace Tc.Gny.SOAApi.ApiBase.Core
{
    public static class ParameterHelper
    {
        public static object[] GenParas(List<ParameterInfo> paras, HttpRequestBase request)
        {
            List<object> objs = new List<object>();

            foreach (var parameterInfo in paras)
            {
                var p = "";
                var fp = request.Form[parameterInfo.Name];
                if (!fp.IsNullOrEmpty())
                {
                    p = fp;
                }
                if (p.IsNullOrEmpty())
                {
                    p = request.QueryString[parameterInfo.Name];
                }
                if (p.IsNullOrEmpty())
                {
                    objs.Add(parameterInfo.DefaultValue);
                    continue;
                }

                var v = ChangeType(p, parameterInfo.ParameterType);
                objs.Add(v);
            }

            return objs.ToArray();
        }

        private static object ChangeType(string v, Type parameterType)
        {
            if (parameterType.IsClass && parameterType.Name != "String")
            {
                return JsonConvert.DeserializeObject(v, parameterType);
            }
            else
            {
                return Convert.ChangeType(v, parameterType);
            }
        }

    }
}
