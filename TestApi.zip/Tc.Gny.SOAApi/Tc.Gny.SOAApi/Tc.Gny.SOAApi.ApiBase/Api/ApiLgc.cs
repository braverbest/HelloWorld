﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Tc.Gny.SOAApi.ApiBase.Base;
using Tc.Gny.SOAApi.ApiBase.Fliter;

namespace Tc.Gny.SOAApi.ApiBase.Api
{
    public class ApiLgc
    {
        public string ApiName { get; set; }

        public string Desc { get; set; }

        public Type ApiType { get; set; }

        public BaseApi ApiInstance { get; set; }

        public Dictionary<string, ApiMethod> ApiMethods
        {
            get;
            set;
        }
    }

    public class ApiMethod
    {
        public string MethodName { get; set; }
        public string FullName { get; set; }
        public string Desc { get; set; }
        public ActionMethodDispatcher Dispatcher { get; set; }
        public List<ParameterInfo> ParameterInfos { get; set; }
        public IApiFilter ApiFilter { get; set; } 
        public IAuthFilter AuthFilter { get; set; }
    }
}
