﻿/*
 陈老师开源奉献--具体技术学习可阅读asp.net mvc4 源代码
 */

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Reflection;
using System.Web;
using Tc.Gny.Framework.Core.Common;
using Tc.Gny.SOAApi.ApiBase.Api;
using Tc.Gny.SOAApi.ApiBase.Args;
using Tc.Gny.SOAApi.ApiBase.Base;
using Tc.Gny.SOAApi.ApiBase.Core;

namespace Tc.Gny.SOAApi.ApiBase
{
    /// <summary>
    /// 执行工厂
    /// </summary>
    public static class ApiExecFactory
    {
        /// <summary>
        /// 执行前
        /// </summary>
        public static event EventHandler<ApiExecutingEventArgs> OnApiExecuting;

        internal static void OnOnApiExecuting(ApiExecutingEventArgs e)
        {
            EventHandler<ApiExecutingEventArgs> handler = OnApiExecuting;
            if (handler != null) handler(null, e);
        }

        public static event EventHandler<ApiExecutedSuccessEventArgs> OnApiExecutedSuccess;

        internal static void OnOnApiExecutedSuccess(ApiExecutedSuccessEventArgs e)
        {
            EventHandler<ApiExecutedSuccessEventArgs> handler = OnApiExecutedSuccess;
            if (handler != null) handler(null, e);
        }

        public static event EventHandler<ApiExecutedErrorEventArgs> OnApiExecutedError;

        internal static void OnOnApiExecutedError(ApiExecutedErrorEventArgs e)
        {
            EventHandler<ApiExecutedErrorEventArgs> handler = OnApiExecutedError;
            if (handler != null) handler(null, e);
        }

        private static Kernel _knl;

        //首先要加载所有的服务
        public static void InitApi()
        {
            _knl = new Kernel();
            var asm = Assembly.Load(new AssemblyName("Tc.Gny.SOAApi.Apis"));
            LoadLgc(asm);
        }

        private static void LoadLgc(Assembly asm)
        {
            foreach (Type i in asm.GetExportedTypes())
            {
                if (!i.IsAbstract && (i.IsSubclassOf(typeof(BaseApi)) && (i.GetConstructor(Type.EmptyTypes) != null)))
                {
                    var lgc = (BaseApi)asm.CreateInstance(i.FullName);
                    lgc.Ctor(_knl);
                    var apiname = i.GetCustomAttributes().GetApiName().ToLower();
                    if (apiname.IsNullOrEmpty())
                    {
                        apiname = i.Name.ToLower();
                    }
                    if (!_knl.Contains(apiname))
                    {
                        var desc = i.GetCustomAttributes().GetApiDesc();
                        _knl.Add(lgc, i, apiname, desc);
                    }
                }
            }

            //加载生命周期
            foreach (var apiLgc in GetLgcs())
            {
                apiLgc.ApiInstance.RaiseLoad();
            }
        }

        public static object ExecApi(string name, string method, HttpRequestBase request)
        {
            if (!_knl.Contains(name))
            {
                throw new Exception("未找到API类型：" + name);
            }
            var ret = _knl.Exec(name, method, request);
            return ret;
        }

        public static List<ApiLgc> GetLgcs()
        {
            return _knl.GetAllLgc();
        }
    }
}
