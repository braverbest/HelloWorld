﻿/*
 陈老师开源奉献--具体技术学习可阅读asp.net mvc4 源代码
 */

using System;
using System.Web;
using Tc.Gny.SOAApi.ApiBase.Core;

namespace Tc.Gny.SOAApi.ApiBase.Base
{
    public abstract class BaseApi : IApi
    {

        protected Kernel Kernel { get; set; }

        protected HttpRequest Request
        {
            get { return HttpContext.Current.Request; }
        }

        protected HttpResponse Response
        {
            get { return HttpContext.Current.Response; }
        }

        protected HttpServerUtility Server
        {
            get { return HttpContext.Current.Server; }
        }

        internal void Ctor(Kernel knl)
        {
            Kernel = knl;
        }

        internal void RaiseLoad()
        {
            OnLoad(Kernel);
        }

        internal void RaiseError(Exception ex)
        {
            OnError(ex);
        }

        protected virtual void OnLoad(Kernel knl)
        {

        }

        protected virtual void OnError(Exception ex)
        {

        }
    }
}
