﻿/*
 陈老师开源奉献--具体技术学习可阅读asp.net mvc4 源代码
 */
namespace Tc.Gny.SOAApi.ApiBase.Base
{
   public  interface IApiLog
    {
    }
}
