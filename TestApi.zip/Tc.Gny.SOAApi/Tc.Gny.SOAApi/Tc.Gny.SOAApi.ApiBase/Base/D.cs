﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tc.Gny.SOAApi.ApiBase.Fliter;

namespace Tc.Gny.SOAApi.ApiBase.Base
{
    //方法注释
    [AttributeUsage(AttributeTargets.Method)]
    public class D : DescriptionAttribute
    {
        private string _desc;

        public D(string desc)
        {
            _desc = desc;
        }

        public override string Description
        {
            get { return _desc; }
        }
    }

    /// <summary>
    /// API接口
    /// </summary>
    [AttributeUsage(AttributeTargets.Class)]
    public class ApiAttribute : Attribute
    {
        /// <summary>
        /// 接口名称
        /// </summary>
        public string ApiName { get; set; }

        /// <summary>
        /// 接口描述
        /// </summary>
        public string Desc { get; set; }

        public ApiAttribute(string name, string desc)
        {
            ApiName = name;
            Desc = desc;
        }

    }


    public static class DExt
    {
        public static string GetDesc(this IEnumerable<Attribute> attrs)
        {
            foreach (var attribute in attrs)
            {
                if (attribute is D)
                {
                    var attr = (D)attribute;
                    return attr.Description;
                }
            }
            return "";
        }

        public static string GetApiName(this IEnumerable<Attribute> attrs)
        {
            foreach (var attribute in attrs)
            {
                if (attribute is ApiAttribute)
                {
                    var attr = (ApiAttribute)attribute;
                    return attr.ApiName;
                }
            }
            return "";
        }

        public static string GetApiDesc(this IEnumerable<Attribute> attrs)
        {
            foreach (var attribute in attrs)
            {
                if (attribute is ApiAttribute)
                {
                    var attr = (ApiAttribute)attribute;
                    return attr.Desc;
                }
            }
            return "";
        }

        public static IApiFilter GetApiFilter(this IEnumerable<Attribute> attrs)
        {
            foreach (var attribute in attrs)
            {
                if (attribute is IApiFilter)
                {
                    var attr = (IApiFilter)attribute;
                    return attr;
                }
            }
            return null;
        }

        public static IAuthFilter GetAuthfilter(this IEnumerable<Attribute> attrs)
        {
            foreach (var attribute in attrs)
            {
                if (attribute is IAuthFilter)
                {
                    var attr = (IAuthFilter)attribute;
                    return attr;
                }
            }
            return null;
        }
    }
}
