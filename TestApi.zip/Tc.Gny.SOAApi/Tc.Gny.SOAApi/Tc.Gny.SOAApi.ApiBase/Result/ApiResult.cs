﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tc.Gny.SOAApi.ApiBase.Result
{
    public enum ResultCode
    {
        //成功
        Success  = 200,
        //没找到api
        NotFoundApi = 404,
        //没找到方法
        NotFoundMehtod = 403,
        //报错
        Error = 500,
        //没有权限
        NoRights = 405,
    }

    public class ApiResult
    {
        /// <summary>
        /// 返回编码
        /// </summary>
        public ResultCode ResultCode { get; set; }

        /// <summary>
        /// 返回结果
        /// </summary>
        public object ResultBody { get; set; }

        /// <summary>
        /// 异常信息
        /// </summary>
        public string Exception { get; set; }
    }
}
