﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tc.Gny.SOAApi.ApiBase.Fliter
{
    public class AuthFilter : Attribute, IAuthFilter
    {
        public virtual void OnAuth(AuthContext context)
        {

        }
    }
}
