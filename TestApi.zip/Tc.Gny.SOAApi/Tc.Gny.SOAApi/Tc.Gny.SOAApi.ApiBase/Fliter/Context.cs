﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using Tc.Gny.SOAApi.ApiBase.Base;
using Tc.Gny.SOAApi.ApiBase.Result;

namespace Tc.Gny.SOAApi.ApiBase.Fliter
{
    public class BaseContext
    {
        /// <summary>
        /// api名称
        /// </summary>
        public string ApiName { get; set; }

        /// <summary>
        /// 方法名称
        /// </summary>
        public string MethodName { get; set; }

        /// <summary>
        /// 接口实例
        /// </summary>
        public BaseApi ApiInstance { get; set; }

        /// <summary>
        /// 返回结果
        /// </summary>
        public ApiResult Result { get; set; }


    }

    /// <summary>
    /// 执行中的结果
    /// </summary>
    public class AuthContext : BaseContext
    {
        /// <summary>
        /// 请求
        /// </summary>
        public HttpRequestBase Request { get; set; }
        
    }

    /// <summary>
    /// 执行中的结果
    /// </summary>
    public class ApiExecutingContext : BaseContext
    {
        /// <summary>
        /// 请求
        /// </summary>
        public HttpRequestBase Request { get; set; }

        /// <summary>
        /// 请求参数
        /// </summary>
        public object[] Paras { get; set; }


    }

    /// <summary>
    /// 执行后的结果
    /// </summary>
    public class ApiExecutedContext : BaseContext
    {
        /// <summary>
        /// 返回结果
        /// </summary>
        public HttpResponse Response { get; set; }
    }
}
