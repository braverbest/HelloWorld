﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tc.Gny.SOAApi.ApiBase.Fliter
{

    public class ApiFilter :Attribute, IApiFilter
    {
        public virtual void OnApiExecuting(ApiExecutingContext context)
        {

        }

        public virtual void OnApiExecuted(ApiExecutedContext context)
        {

        }
    }
}
