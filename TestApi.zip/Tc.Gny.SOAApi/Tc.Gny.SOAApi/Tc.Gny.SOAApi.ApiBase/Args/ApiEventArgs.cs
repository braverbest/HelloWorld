﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using Tc.Gny.SOAApi.ApiBase.Result;

namespace Tc.Gny.SOAApi.ApiBase.Args
{
    /// <summary>
    /// 执行前的事件参数
    /// </summary>
    public class ApiExecutingEventArgs : EventArgs
    {
        public ApiExecutingEventArgs(string apiname, string methodName, HttpRequestBase request)
        {
            ApiName = apiname;
            MethodName = methodName;
            Request = request;
        }

        public string ApiName { get; set; }

        public string MethodName { get; set; }

        public HttpRequestBase Request { get; set; }

    }

    /// <summary>
    /// 执行后的事件参数
    /// </summary>
    public class ApiExecutedSuccessEventArgs : EventArgs
    {
        public ApiExecutedSuccessEventArgs(string apiname, string methodName, HttpRequestBase request, ApiResult result)
        {
            ApiName = apiname;
            MethodName = methodName;
            Request = request;
            Result = result;
        }

        public string ApiName { get; set; }

        public string MethodName { get; set; }

        public HttpRequestBase Request { get; set; }

        public ApiResult Result { get; set; }

    }

    /// <summary>
    /// 执行后的事件参数
    /// </summary>
    public class ApiExecutedErrorEventArgs : EventArgs
    {
        public ApiExecutedErrorEventArgs(string apiname, string methodName, HttpRequestBase request, ApiResult result,Exception ex)
        {
            ApiName = apiname;
            MethodName = methodName;
            Request = request;
            Result = result;
            Exception = ex;
        }

        public string ApiName { get; set; }

        public string MethodName { get; set; }

        public HttpRequestBase Request { get; set; }

        public ApiResult Result { get; set; }

        public Exception Exception { get; set; }
    }
}
