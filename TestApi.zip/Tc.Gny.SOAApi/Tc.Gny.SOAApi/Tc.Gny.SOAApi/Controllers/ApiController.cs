﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.Mvc;
using Newtonsoft.Json;
using Tc.Gny.SOAApi.ApiBase;
using Tc.Gny.SOAApi.ApiBase.Base;

namespace Tc.Gny.SOAApi.Controllers
{
    public class ApiController : Controller
    {
        //
        // 表达式树动态调用方法，编写高效可扩展SOA
        public JsonResult Index(string api, string method)
        {
            Stopwatch sw = new Stopwatch();
            sw.Start();

            //控制服务
            //调度服务
            var ret = ApiExecFactory.ExecApi(api.ToLower(), method.ToLower(), Request);

            sw.Stop();
            //监控服务

            if (ret == null)
            {
                return Json("", JsonRequestBehavior.AllowGet);
            }
            return Json(ret, JsonRequestBehavior.AllowGet);
        }

    }
}
