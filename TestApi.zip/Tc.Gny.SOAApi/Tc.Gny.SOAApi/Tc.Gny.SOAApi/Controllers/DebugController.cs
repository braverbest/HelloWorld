﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Tc.Gny.SOAApi.ApiBase;
using Tc.Gny.SOAApi.ApiModels;

namespace Tc.Gny.SOAApi.Controllers
{
    public class DebugController : Controller
    {
        //
        // GET: /Debug/

        public ActionResult Index()
        {
            var apis = ApiExecFactory.GetLgcs();
            return View(apis);
        }

        public ActionResult Debug(string a, string m)
        {
            var apis = ApiExecFactory.GetLgcs();
            var api = apis.FirstOrDefault(p => p.ApiName == a.ToLower());
            if (api != null)
            {
                var mehtod = api.ApiMethods.FirstOrDefault(p => p.Key == m).Value;
                ViewBag.api = api;
                ViewBag.cfg = CallCfg.Instance.CallCfgs.FirstOrDefault().Value;
                return View(mehtod);
            }
            return HttpNotFound();
        }

        [HttpPost]
        public ActionResult DebugJson(string a, string m)
        {
            var cfg = CallCfg.Instance.CallCfgs.FirstOrDefault().Value;
            var ret = ApiExecFactory.ExecApi(a, m, Request);

            return Json(ret);
        }

        public string GetToken(string a, string m)
        {
            var keys = Request.Form.Keys;
            var parastr = "";
            foreach (var k in keys)
            {
                parastr += Request.Form[k.ToString()];
            }
            var cfg = CallCfg.Instance.CallCfgs.FirstOrDefault().Value;
            var currentToken = Tc.Gny.Framework.Core.Security.Encypt.MD5(a+m+ parastr+ cfg.AppKey);
            return currentToken;
        }

    }
}
