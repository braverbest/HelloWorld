﻿using System.Collections.Generic;

namespace Tc.Gny.SOAApi.ApiModels
{
    public class TestPara
    {
        public string Name { get; set; }

        public string Val { get; set; }

        public List<TestPara> Paras { get; set; } 
    }
}
