﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Xml.Linq;
using Tc.Gny.Framework.Core.Common;

namespace Tc.Gny.SOAApi.ApiModels
{
    public class CallCfg : SingleTon<CallCfg>
    {
        public Dictionary<string, cfgModel> CallCfgs;

        public CallCfg()
        {
            var doc = XDocument.Load(HttpContext.Current.Server.MapPath("/App_Data/cfg/cfg.xml"));
            var list = doc.Descendants("app").Select(p => new cfgModel()
            {
                AppId = (string)p.Element("appid"),
                AppKey = (string)p.Element("appkey")
            });
            CallCfgs = list.ToDictionary(p => p.AppId, x => x);
        }
    }

    public class cfgModel
    {
        /// <summary>
        /// 调用方id
        /// </summary>
        public string AppId { get; set; }

        /// <summary>
        /// 调用方名称
        /// </summary>
        public string AppKey { get; set; }
    }
}
