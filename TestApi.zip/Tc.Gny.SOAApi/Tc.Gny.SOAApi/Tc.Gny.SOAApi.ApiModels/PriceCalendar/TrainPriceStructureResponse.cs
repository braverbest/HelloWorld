﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tc.Gny.SOAApi.ApiModels.PriceCalendar
{
    /// <summary>
    /// 火车票价格体系响应实体
    /// </summary>
    public class TrainPriceStructureResponse
    {
        /// <summary>
        /// 空参构造
        /// </summary>
        public TrainPriceStructureResponse()
        {
            this.PickUps = new List<PickUpResource>();
            this.OptimalTrains = new List<TrainResource>();
            this.AllTrains = new List<TrainResource>();
        }

        /// <summary>
        /// 动态酒店附加价
        /// </summary>
        public int IncreasePrice { get; set; }

        /// <summary>
        /// 酒店资源价格
        /// </summary>
        public List<HotelResource> Hotels { get; set; }
        
        /// <summary>
        /// 地接资源价格体系
        /// </summary>
        public List<PickUpResource> PickUps { get; set; }

        /// <summary>
        /// 最优班次信息
        /// </summary>
        public List<TrainResource> OptimalTrains { get; set; }

        /// <summary>
        /// 所有班次列表
        /// </summary>
        public List<TrainResource> AllTrains { get; set; }
    }

    /// <summary>
    /// 火车票资源
    /// </summary>
    public class TrainResource
    {
        /// <summary>
        /// 1-去程，2-返程
        /// </summary>
        public int RouteType { get; set; }
        /// <summary>
        /// 出发日期
        /// </summary>
        public string TrainDate { get; set; }
        /// <summary>
        /// 车次号
        /// </summary>
        public string TrainNo { get; set; }
        /// <summary>
        /// 车次类型
        /// </summary>
        public string TrainClass { get; set; }
        /// <summary>
        /// 出发时间
        /// </summary>
        public string FromTime { get; set; }
        /// <summary>
        /// 到达时间
        /// </summary>
        public string ToTime { get; set; }
        /// <summary>
        /// 行驶时间 约几小时几分钟
        /// </summary>
        public string RunTime { get; set; }
        /// <summary>
        /// 出发站
        /// </summary>
        public string FromStation { get; set; }
        /// <summary>
        /// 到达站
        /// </summary>
        public string ToStation { get; set; }
        /// <summary>
        /// 耗时几分钟
        /// </summary>
        public double RunTimeSpan { get; set; }
        /// <summary>
        /// 出发站Code
        /// </summary>
        public string FromStationCode { get; set; }
        /// <summary>
        /// 目的地站Code
        /// </summary>
        public string ToStationCode { get; set; }
        /// <summary>
        /// 出站类别 2：终点 1：路过
        /// </summary>
        public int FromPassType { get; set; }
        /// <summary>
        /// 到站类别 2：终点 1：路过
        /// </summary>
        public int ToPassType { get; set; }
        /// <summary>
        /// 其它座次
        /// </summary>
        public Dictionary<string, TrainSeat> TrainSeats { get; set; }
    }

    /// <summary>
    /// 火车票其它座次
    /// </summary>
    public class TrainSeat
    {
        /// <summary>
        /// 中文名
        /// </summary>
        public string SeatName { get; set; }
        /// <summary>
        /// 价格
        /// </summary>
        public double Price { get; set; }
        /// <summary>
        /// 状态
        /// </summary>
        public int SeatState { get; set; }
        /// <summary>
        /// 座位数
        /// </summary>
        public string TicketCount { get; set; }
        /// <summary>
        /// 儿童票价格
        /// </summary>
        public double ChildPrice { get; set; }
        /// <summary>
        /// 儿童票标识
        /// </summary>
        public int IsChildPrice { get; set; }
    }
}