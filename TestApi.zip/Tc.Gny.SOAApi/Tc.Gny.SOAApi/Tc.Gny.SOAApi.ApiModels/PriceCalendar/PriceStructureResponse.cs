﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tc.Gny.SOAApi.ApiModels.PriceCalendar
{
    /// <summary>
    /// 价格体系响应实体
    /// </summary>
    public class PriceStructureResponse
    {
        public PriceStructureResponse()
        {
            this.Schemes = new List<PriceScheme>();
        }

        /// <summary>
        /// 价格方案
        /// </summary>
        public List<PriceScheme> Schemes { get; set; }
    }

    /// <summary>
    /// 价格方案明细
    /// </summary>
    public class PriceScheme
    {
        public PriceScheme()
        {
            this.Structures = new List<StructureDetail>();
        }

        /// <summary>
        /// 方案ID
        /// </summary>
        public int SchemeId { get; set; }
        /// <summary>
        /// 方案名称
        /// </summary>
        public string SchemeName { get; set; }
        /// <summary>
        /// 方案描述
        /// </summary>
        public string SchemeDes { get; set; }
        /// <summary>
        /// 方案类型：1、基础方案，2、升级方案
        /// </summary>
        public int SchemeType { get; set; }
        /// <summary>
        /// 库存类型: 1、库存 ，2、询位，3、不限库存
        /// </summary>
        public int StockType { get; set; }
        /// <summary>
        /// 库存(0可售，-2表示停团，-1表示满团，>0剩余库存) 
        /// </summary>
        public int StockNum { get; set; }
        /// <summary>
        /// 价格体系明细
        /// </summary>
        public List<StructureDetail> Structures { get; set; }
    }

    /// <summary>
    /// 价格体系明细
    /// </summary>
    public class StructureDetail
    {
        /// <summary>
        /// 价格体系ID，采销产品
        /// </summary>
        public int PriceId { get; set; }
        /// <summary>
        /// 价格体系名称
        /// </summary>
        public string PriceName { get; set; }
        /// <summary>
        /// 价格类型 ：0未知， 1 成人，2 儿童占床， 3婴儿， 4老年人，5 单房差， 6 加床费， 7单产品，8儿童不占床，9儿童≤1.2m
        /// </summary>
        public int PriceType { get; set; }
        /// <summary>
        /// 同程价
        /// </summary>
        public int AmountDirect { get; set; }
    }
}