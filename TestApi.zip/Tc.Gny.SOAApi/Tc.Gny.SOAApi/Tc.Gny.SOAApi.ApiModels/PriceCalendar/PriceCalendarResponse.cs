﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tc.Gny.SOAApi.ApiModels.PriceCalendar
{
    /// <summary>
    /// 价格日历响应实体
    /// </summary>
    public class PriceCalendarResponse
    {
        /// <summary>
        /// 无参构造
        /// </summary>
        public PriceCalendarResponse()
        {
            this.Prices = new List<PriceDetail>();
        }

        /// <summary>
        /// 产品ID
        /// </summary>
        public int LineId { get; set; }
        /// <summary>
        /// 活动ID
        /// </summary>
        public int ActivityId { get; set; }
        /// <summary>
        /// 期数ID
        /// </summary>
        public int PeriodsId { get; set; }
        /// <summary>
        /// 活动类型（0:其他；1：预售；2：抢购；3：秒杀）
        /// </summary>
        public int ActivityType { get; set; }
        /// <summary>
        /// 价格日历明细
        /// </summary>
        public List<PriceDetail> Prices { get; set; }
    }

    /// <summary>
    /// 价格日历明细
    /// </summary>
    public class PriceDetail
    {
        /// <summary>
        /// 产品団期
        /// </summary>
        public DateTime LineDate { get; set; }
        /// <summary>
        /// 价格体系ID，采销产品
        /// </summary>
        public int PriceId { get; set; }
        /// <summary>
        /// 价格体系名称
        /// </summary>
        public string PriceName { get; set; }
        /// <summary>
        /// 价格类型 ：0未知， 1 成人，2 儿童占床， 3婴儿， 4老年人，5 单房差， 6 加床费， 7单产品，8儿童不占床，9儿童≤1.2m
        /// </summary>
        public int PriceType { get; set; }
        /// <summary>
        /// 同程价
        /// </summary>
        public int AmountDirect { get; set; }
        /// <summary>
        /// 0可售，-2表示停团，-1表示满团
        /// </summary>
        public int ResidualCount { get; set; }
        /// <summary>
        /// 是否参加立返活动
        /// </summary>
        public bool IsActLiFan { get; set; }
        /// <summary>
        /// 立返规则标识
        /// </summary>
        public string LiFanRuleDes { get; set; } 
    }
}
