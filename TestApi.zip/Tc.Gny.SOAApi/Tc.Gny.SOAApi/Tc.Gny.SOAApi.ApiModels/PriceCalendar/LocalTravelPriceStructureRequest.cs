﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tc.Gny.SOAApi.ApiModels.PriceCalendar
{
    /// <summary>
    /// 地接价格体系请求实体
    /// </summary>
    public class LocalTravelPriceStructureRequest
    {
        /// <summary>
        /// 产品ID
        /// </summary>
        public int LineId { get; set; }
        /// <summary>
        /// 活动ID
        /// </summary>
        public int ActivityId { get; set; }
        /// <summary>
        /// 期数ID
        /// </summary>
        public int PeriodsId { get; set; }
        /// <summary>
        /// 団期
        /// </summary>
        public DateTime LineDate { get; set; }
        /// <summary>
        /// 出发城市ID
        /// </summary>
        public int DepId { get; set; }
    }
}
