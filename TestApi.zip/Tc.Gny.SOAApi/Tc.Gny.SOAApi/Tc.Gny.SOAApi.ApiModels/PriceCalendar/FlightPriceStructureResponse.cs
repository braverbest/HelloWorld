﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tc.Gny.SOAApi.ApiModels.PriceCalendar
{
    /// <summary>
    /// 动态产品价格体系响应实体
    /// </summary>
    public class FlightPriceStructureResponse
    {
        /// <summary>
        /// 空参构造
        /// </summary>
        public FlightPriceStructureResponse()
        {
            this.PickUps = new List<PickUpResource>();
            this.OptimalFlights = new List<FlightResource>();
            this.AllFlights = new List<FlightResource>();
        }

        /// <summary>
        /// 动态酒店附加价
        /// </summary>
        public int IncreasePrice { get; set; }

        /// <summary>
        /// 酒店资源价格
        /// </summary>
        public List<HotelResource> Hotels { get; set; }
        
        /// <summary>
        /// 地接资源价格体系
        /// </summary>
        public List<PickUpResource> PickUps { get; set; }

        /// <summary>
        /// 最优航班信息
        /// </summary>
        public List<FlightResource> OptimalFlights { get; set; }

        /// <summary>
        /// 所有航班次列表
        /// </summary>
        public List<FlightResource> AllFlights { get; set; }
    }

    /// <summary>
    /// 酒店资源
    /// </summary>
    public class HotelResource
    {
        /// <summary>
        /// 酒店ID
        /// </summary>
        public int HotelId { get; set; }
        /// <summary>
        /// 酒店名称
        /// </summary>
        public string HotelName { get; set; }
        /// <summary>
        /// 酒店图片链接
        /// </summary>
        public string HotelImgUrl { get; set; }
        /// <summary>
        /// 房型ID
        /// </summary>
        public int RoomId { get; set; }
        /// <summary>
        /// 房型名称
        /// </summary>
        public string RoomName { get; set; }
        /// <summary>
        /// 政策ID
        /// </summary>
        public int PolicyId { get; set; }
        /// <summary>
        /// 政策名称
        /// </summary>
        public string PolicyName { get; set; }
        /// <summary>
        /// 入店日期
        /// </summary>
        public string CheckInDate { get; set; }
        /// <summary>
        /// 离店日期
        /// </summary>
        public string CheckOutDate { get; set; }
        /// <summary>
        /// 晚数(几晚)
        /// </summary>
        public int Nights { get; set; }
        /// <summary>
        /// 酒店价格
        /// </summary>
        public int HotelPrice { get; set; }
    }

    /// <summary>
    /// 地接资源
    /// </summary>
    public class PickUpResource
    {
        /// <summary>
        /// 价格规则Id
        /// </summary>
        public int PriceId { get; set; }
        /// <summary>
        /// 价格体系名称
        /// </summary>
        public string PriceName { get; set; }
        /// <summary>
        /// 销售价
        /// </summary>
        public int SellPrice { get; set; }
        /// <summary>
        /// 结算价
        /// </summary>
        public int SettlementPrice { get; set; }
        /// <summary>
        /// 价格类型 1-成人价 ,5-单房差 ,8-儿童不占床
        /// </summary>
        public int PriceType { get; set; }
        /// <summary>
        /// 计算人数 0-不计算 ,1-计算
        /// </summary>
        public int ReckonPersons { get; set; }
        /// <summary>
        /// 前端呈现 0-不呈现 1-呈现
        /// </summary>
        public int IsShow { get; set; }
    }

    /// <summary>
    /// 机票资源
    /// </summary>
    public class FlightResource
    {
        /// <summary>
        /// 1-套餐 2-自由组合
        /// </summary>
        public int FlightInfoType { get; set; }
        /// <summary>
        /// 套餐成人往返总价
        /// </summary>
        public decimal AdultTotalPrice { get; set; }
        /// <summary>
        /// 套餐儿童往返总价
        /// </summary>
        public decimal ChildTotalPrice { get; set; }
        /// <summary>
        /// 机票往返价格
        /// </summary>
        public List<FlightPrice> SinglePrices { get; set; }
    }

    /// <summary>
    /// 机票价格
    /// </summary>
    public class FlightPrice
    {
        /// <summary>
        /// 资源标识，1-静态，2-动态
        /// </summary>
        public int ResourceType { get; set; }
        /// <summary>
        /// 静态资源ID
        /// </summary>
        public int ResourceId { get; set; }
        /// <summary>
        /// 1-去程，2-返程
        /// </summary>
        public int RouteType { get; set; }
        /// <summary>
        /// 起飞日期
        /// </summary>
        public string FlyDate { get; set; }
        /// <summary>
        /// 起飞时间
        /// </summary>
        public string OffTime { get; set; }
        /// <summary>
        /// 到达时间
        /// </summary>
        public string ArriveTime { get; set; }
        /// <summary>
        /// 约几小时几分钟
        /// </summary>
        public string FlyTime { get; set; }
        /// <summary>
        /// 舱位名称
        /// </summary>
        public string CabinName { get; set; }
        /// <summary>
        /// 机型
        /// </summary>
        public string EquipmentCode { get; set; }
        /// <summary>
        /// 机型类型（1-小型飞机；2-中型飞机；3-大型飞机；）
        /// </summary>
        public string ACPlaneType { get; set; }
        /// <summary>
        /// 起飞机场简称
        /// </summary>
        public string StratAirportName { get; set; }
        /// <summary>
        /// 出发机场所在城市名称
        /// </summary>
        public string StartCityName { get; set; }
        /// <summary>
        /// 抵达机场简称
        /// </summary>
        public string ArriveAirportName { get; set; }
        /// <summary>
        /// 抵达机场所在城市名称
        /// </summary>
        public string ArriveCityName { get; set; }
        /// <summary>
        /// 航司二字码
        /// </summary>
        public string AirCompanyCode { get; set; }
        /// <summary>
        /// 航司名称
        /// </summary>
        public string AirCompanyName { get; set; }
        /// <summary>
        /// 航班号
        /// </summary>
        public string FlightNo { get; set; }
        /// <summary>
        /// 经停次数
        /// </summary>
        public int StopNum { get; set; }
        /// <summary>
        /// 出发机场航站楼
        /// </summary>
        public string BoardPoint { get; set; }
        /// <summary>
        /// 抵达机场航站楼
        /// </summary>
        public string OffPoint { get; set; }
        /// <summary>
        /// 推荐航班 1：是 0：否（默认）
        /// </summary>
        public int RecFlight { get; set; }
        /// <summary>
        /// 成人价
        /// </summary>
        public decimal AdultPrice { get; set; }
        /// <summary>
        /// 儿童价
        /// </summary>
        public decimal ChildPrice { get; set; }
    }
}