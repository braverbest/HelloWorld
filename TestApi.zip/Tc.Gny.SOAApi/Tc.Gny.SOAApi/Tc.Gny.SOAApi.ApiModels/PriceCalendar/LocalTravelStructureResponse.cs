﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tc.Gny.SOAApi.ApiModels.PriceCalendar
{
    /// <summary>
    /// 地接价格体系响应实体
    /// </summary>
    public class LocalTravelStructureResponse
    {
        /// <summary>
        /// 空参构造函数
        /// </summary>
        public LocalTravelStructureResponse()
        {
            this.PickUps = new List<PickUpResource>();
        }

        /// <summary>
        /// 地接价格体系
        /// </summary>
        public List<PickUpResource> PickUps { get; set; }
    }
}
