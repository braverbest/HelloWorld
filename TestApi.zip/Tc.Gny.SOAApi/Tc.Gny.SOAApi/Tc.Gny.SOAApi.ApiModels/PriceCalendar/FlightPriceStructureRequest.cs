﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tc.Gny.SOAApi.ApiModels.PriceCalendar
{
    /// <summary>
    /// 动态价格体系请求参数
    /// </summary>
    public class FlightPriceStructureRequest
    {
        /// <summary>
        /// 产品ID
        /// </summary>
        public int LineId { get; set; }
        /// <summary>
        /// 活动ID
        /// </summary>
        public int ActivityId { get; set; }
        /// <summary>
        /// 期数ID
        /// </summary>
        public int PeriodsId { get; set; }
        /// <summary>
        /// 団期
        /// </summary>
        public DateTime LineDate { get; set; }
        /// <summary>
        /// 出发城市ID
        /// </summary>
        public int DepId { get; set; }
        /// <summary>
        /// 产品类型（0：默认；1：采销分离；2：火车票固定打包；3：机票自由组合(含静态交通)；4：火车票自由组合；5：机票酒店；6：火车票酒店；7、飞机去火车返+地接；8、火车去飞机返+地接)
        /// </summary>
        public int ProType { get; set; }
    }
}