﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tc.Gny.SOAApi.ApiModels.PriceCalendar;
using TongCheng.SOA.Core.Entities;
using TongCheng.SOA.Core.SOAHttp;
using TongCheng.SOA.Interface.GuoNeiYouQuery.Product.Entities;
using TongCheng.SOA.Interface.GuoNeiYouQuery.Resource.Entities;
using TongCheng.SOA.Interface.GuoNeiYouQuery.Resource.Entities.Train;
using Tc.Gny.Framework.Core.Common;
using Tc.Gny.SOAApi.Entities;
using Tc.Gny.Framework.ORM.Core;

namespace Tc.Gny.SOAApi.Services.PriceCalendar
{
    /// <summary>
    /// 价格日历接口
    /// </summary>
    public interface IPriceCalendarService
    {
        /// <summary>
        /// 获取价格日历呈现数据
        /// </summary>
        /// <param name="request">价格日历请求实体</param>
        /// <returns>价格日历响应实体</returns>
        PriceCalendarResponse GetCalendarData(PriceCalendarRequest request);

        /// <summary>
        /// 获取价格体系明细数据
        /// </summary>
        /// <param name="request">价格体系请求实体</param>
        /// <returns>价格体系响应实体</returns>
        PriceStructureResponse GetStructureData(PriceStructureRequest request);

        /// <summary>
        /// 动态机票价格体系明细数据
        /// </summary>
        /// <param name="request">价格体系请求实体</param>
        /// <returns>价格体系响应实体</returns>
        FlightPriceStructureResponse GetFlightStructureData(FlightPriceStructureRequest request);

        /// <summary>
        /// 动态火车票价格体系明细数据
        /// </summary>
        /// <param name="request">价格体系请求实体</param>
        /// <returns>价格体系响应实体</returns>
        TrainPriceStructureResponse GetTrainStructureData(TrainPriceStructureRequest request);
        
        /// <summary>
        /// 获取地接价格体系明细数据
        /// </summary>
        /// <param name="request">价格体系请求实体</param>
        /// <returns>价格体系响应实体</returns>
        LocalTravelStructureResponse GetLocalTravelStructureData(LocalTravelPriceStructureRequest request);
    }

    /// <summary>
    /// 价格日历接口实现
    /// </summary>
    public class PriceCalendarService : IPriceCalendarService
    {
        #region 实现

        /// <summary>
        /// 获取价格日历呈现数据
        /// </summary>
        /// <param name="request">价格日历请求实体</param>
        /// <returns>价格日历响应实体</returns>
        public PriceCalendarResponse GetCalendarData(PriceCalendarRequest request)
        {
            var res = new PriceCalendarResponse();

            if (request == null) return res;

            if (request.ProType >= 0 && request.ProType <= 2)
            {
                res = GetCommonLinePriceCalendar(request);
            }
            else if (request.ProType == 3 || request.ProType == 5 || request.ProType == 7 || request.ProType == 8)
            {
                res = GetDynamicFlightPriceCalendar(request);
            }
            else if (request.ProType == 4 || request.ProType == 6)
            {
                res = GetDynamicTrainPriceCalendar(request);
            }

            return res;
        }

        /// <summary>
        /// 获取价格体系明细数据
        /// </summary>
        /// <param name="request">价格体系请求实体</param>
        /// <returns>价格体系响应实体</returns>
        public PriceStructureResponse GetStructureData(PriceStructureRequest request)
        {
            var res = new PriceStructureResponse();

            if (request == null) return res;

            if (request.IsEBLine == 1)
            {
                res = GetEbCommonLinePriceStructure(request);
            }
            else
            {
                res = GetCommonLinePriceStructure(request);
            }

            return res;
        }

        /// <summary>
        /// 动态机票价格体系明细数据
        /// </summary>
        /// <param name="request">价格体系请求实体</param>
        /// <returns>价格体系响应实体</returns>
        public FlightPriceStructureResponse GetFlightStructureData(FlightPriceStructureRequest request)
        {
            var res = new FlightPriceStructureResponse();

            if (request == null) return res;

            #region 资源总价,推荐航班,航班列表

            var pickUpTask = Task.Factory.StartNew<GnySynthesizePriceResponse>(() =>
            {
                var soaRes = SOAHttpHelper.GetResposne<GnySynthesizePriceResponse>(new GnySynthesizePriceRequest
                {
                    LineId = request.LineId,
                    LeavePortCityId = request.DepId,
                    PriceDate = request.LineDate,
                    ActivityId = request.ActivityId,
                    PeriodsId = request.PeriodsId
                }, new RequestHeaderEntity("GetSynthesizePrice"));
                if (soaRes == null) return null;
                return soaRes.Body;
            });

            var optimalTask = Task.Factory.StartNew(() =>
            {
                var soaRes = SOAHttpHelper.GetResposne<FlightComboListResponse>(new FlightComboListRequest
                {
                    LineId = request.LineId,
                    DateGo = request.LineDate,
                    StartCityId = request.DepId,
                    DataType = 1
                }, new RequestHeaderEntity("GetComboFlightInfo"));
                if (soaRes == null) return null;
                return soaRes.Body;
            });

            var allTask = Task.Factory.StartNew(() =>
            {
                var soaRes = SOAHttpHelper.GetResposne<FlightComboListResponse>(new FlightComboListRequest
                {
                    LineId = request.LineId,
                    DateGo = request.LineDate,
                    StartCityId = request.DepId,
                    DataType = 2
                }, new RequestHeaderEntity("GetComboFlightInfo"));
                if (soaRes == null) return null;
                return soaRes.Body;
            });

            #endregion

            try
            {
                Task.WaitAll(pickUpTask, optimalTask, allTask);
            }
            catch (AggregateException ex)
            {

            }

            res.PickUps.AddRange(GetPickUpPrice(pickUpTask.Result));
            res.OptimalFlights.AddRange(GetFlightPrice(optimalTask.Result));
            res.AllFlights.AddRange(GetFlightPrice(allTask.Result));

            if (request.ProType == 5)
            {
                var tuple = this.GetHotelResource(request.LineId, request.LineDate);
                if (tuple == null) return res;
                res.IncreasePrice = tuple.Item1;
                res.Hotels = tuple.Item2;
            }

            return res;
        }

        /// <summary>
        /// 动态火车票价格体系明细数据
        /// </summary>
        /// <param name="request">价格体系请求实体</param>
        /// <returns>价格体系响应实体</returns>
        public TrainPriceStructureResponse GetTrainStructureData(TrainPriceStructureRequest request)
        {
            var res = new TrainPriceStructureResponse();

            if (request == null) return res;

            #region 火车票去程

            var soaRes = SOAHttpHelper.GetResposne<TrainInfoListResponseEntity>(new TrainInfoListRequsetEntity
            {
                LineId = request.LineId,
                TrainDate = request.LineDate,
                GoBack = 1,
                FromCityName = request.DepName,
                PersonCount = request.PersonCount
            }, new RequestHeaderEntity("GetAllTrainInfo"));
            if (soaRes == null || soaRes.Body == null || soaRes.Body.DefaultTrainInfo == null) return res;

            var trainDate = soaRes.Body.TrainDate;
            var defaultTrain = soaRes.Body.DefaultTrainInfo;
            var goDate = string.Format("{0} {1}", trainDate.ToString("yyyy-MM-dd"), defaultTrain.FromTime).ToDateTime();
            var arriveDate = goDate.AddMinutes(defaultTrain.RunTimeSpan.ToInt());

            res.OptimalTrains.AddRange(GetTrainPrice(1, trainDate, new List<DynamicTrainInfo>() { soaRes.Body.DefaultTrainInfo }));
            res.AllTrains.AddRange(GetTrainPrice(1, trainDate, soaRes.Body.TrainInfoSimpleList));

            #endregion

            #region 并行获取火车票返程和资源总价

            var pickUpTask = Task.Factory.StartNew<GnySynthesizePriceResponse>(() =>
            {
                var pickUpRes = SOAHttpHelper.GetResposne<GnySynthesizePriceResponse>(new GnySynthesizePriceRequest
                {
                    LineId = request.LineId,
                    LeavePortCityId = request.DepId,
                    PriceDate = arriveDate,
                    ActivityId = request.ActivityId,
                    PeriodsId = request.PeriodsId
                }, new RequestHeaderEntity("GetSynthesizePrice"));
                if (pickUpRes == null) return null;
                return pickUpRes.Body;
            });

            var backTask = Task.Factory.StartNew<TrainInfoListResponseEntity>(() =>
            {
                var backRes = SOAHttpHelper.GetResposne<TrainInfoListResponseEntity>(new TrainInfoListRequsetEntity
                {
                    LineId = request.LineId,
                    TrainDate = request.LineDate,
                    GoBack = 2,
                    ArrivalDate = arriveDate,
                    FromCityName = request.DepName,
                    PersonCount = request.PersonCount
                }, new RequestHeaderEntity("GetAllTrainInfo"));
                if (backRes == null) return null;
                return backRes.Body;
            });

            try
            {
                Task.WaitAll(pickUpTask, backTask);
            }
            catch (AggregateException ex)
            {
 
            }

            var pickUpPrice = pickUpTask.Result;
            var backPrice = backTask.Result;

            res.PickUps.AddRange(GetPickUpPrice(pickUpPrice));
            res.OptimalTrains.AddRange(GetTrainPrice(2, backPrice.TrainDate, new List<DynamicTrainInfo>() { backPrice.DefaultTrainInfo }));
            res.AllTrains.AddRange(GetTrainPrice(2, backPrice.TrainDate, backPrice.TrainInfoSimpleList));

            if (request.ProType == 5)
            {
                var tuple = this.GetHotelResource(request.LineId, request.LineDate);
                if (tuple == null) return res;
                res.IncreasePrice = tuple.Item1;
                res.Hotels = tuple.Item2;
            }

            #endregion

            return res;
        }

        /// <summary>
        /// 地接价格体系明细数据
        /// </summary>
        /// <param name="request">价格体系请求实体</param>
        /// <returns>价格体系响应实体</returns>
        public LocalTravelStructureResponse GetLocalTravelStructureData(LocalTravelPriceStructureRequest request)
        {
            var res = new LocalTravelStructureResponse();

            var pickUpRes = SOAHttpHelper.GetResposne<GnySynthesizePriceResponse>(new GnySynthesizePriceRequest
            {
                LineId = request.LineId,
                LeavePortCityId = request.DepId,
                PriceDate = request.LineDate,
                ActivityId = request.ActivityId,
                PeriodsId = request.PeriodsId
            }, new RequestHeaderEntity("GetSynthesizePrice"));
            if (pickUpRes == null || pickUpRes.Body == null) return res;
            res.PickUps.AddRange(this.GetPickUpPrice(pickUpRes.Body));

            return res;
        }

        #endregion

        #region 私有方法

        /// <summary>
        /// 获取普通产品价格日历
        /// </summary>
        /// <param name="request">价格日历请求实体</param>
        /// <returns>价格日历响应实体</returns>
        private PriceCalendarResponse GetCommonLinePriceCalendar(PriceCalendarRequest request)
        {
            var res = new PriceCalendarResponse();

            var soaRes = SOAHttpHelper.GetResposne<LinePriceResponse>(new LinePriceRequest
            {
                LineId = request.LineId,
                CalendarPriceMethod = CalendarPriceMethod.GetAllCalendarPriceByLineId,
                IsCalendarShow = true,
                IVID = request.ActivityId,
                IVPeriodNo = request.PeriodsId
            }, new RequestHeaderEntity("GetLinePrice"));

            if (soaRes == null || soaRes.Body == null) return res;
            res.LineId = request.LineId;
            res.ActivityId = soaRes.Body.ActId;
            res.PeriodsId = soaRes.Body.ActConfigId;
            res.ActivityType = soaRes.Body.OrderActiveTypeId;

            if (soaRes.Body.PriceList == null || !soaRes.Body.PriceList.Any()) return res;
            res.Prices.AddRange(
                soaRes.Body.PriceList.Where(p => p.StartDate.Year == request.Year && p.StartDate.Month == request.Month)
                .Select(p => new PriceDetail
            {
                LineDate = p.StartDate,
                PriceId = p.PriceId,
                PriceName = p.PriceName,
                PriceType = p.PriceType,
                AmountDirect = p.AmountDirect,
                ResidualCount = p.ResidualCount,
                IsActLiFan = p.IsActLiFan,
                LiFanRuleDes = p.LiFanRuleDes
            }));

            return res;
        }

        /// <summary>
        /// 获取动态机票价格日历
        /// </summary>
        /// <param name="request">价格日历请求实体</param>
        /// <returns>价格日历响应实体</returns>
        private PriceCalendarResponse GetDynamicFlightPriceCalendar(PriceCalendarRequest request)
        {
            var res = new PriceCalendarResponse()
            {
                LineId = request.LineId,
                ActivityId = request.ActivityId,
                PeriodsId = request.PeriodsId,
                ActivityType = 0
            };

            var soaRes = SOAHttpHelper.GetResposne<FlightPriceListResponse>(new FlightPriceListRequest
            {
                LineId = request.LineId,
                Departure = request.DepId.ToString(),
                FromPlatment = request.PlatForm,
                ActivityId = request.ActivityId,
                PeriodsId = request.PeriodsId
            }, new RequestHeaderEntity("GetAllFlightPrice"));

            if (soaRes == null || soaRes.Body == null) return res;

            if (soaRes.Body.LinePrices == null || !soaRes.Body.LinePrices.Any()) return res;
            res.Prices.AddRange(
                soaRes.Body.LinePrices.Where(p => p.LineDate.Year == request.Year && p.LineDate.Month == request.Month)
                .Select(p => new PriceDetail
                {
                    LineDate = p.LineDate,
                    PriceId = 1,
                    PriceName = p.PriceName,
                    PriceType = 1,
                    AmountDirect = (int)p.LinePrice,
                    ResidualCount = p.ResidualCount,
                    IsActLiFan = p.IsActLiFan,
                    LiFanRuleDes = p.LiFanRuleDes
                }));

            return res;
        }

        /// <summary>
        /// 获取动态火车票价格日历
        /// </summary>
        /// <param name="request">价格日历请求实体</param>
        /// <returns>价格日历响应实体</returns>
        private PriceCalendarResponse GetDynamicTrainPriceCalendar(PriceCalendarRequest request)
        {
            var res = new PriceCalendarResponse()
            {
                LineId = request.LineId,
                ActivityId = request.ActivityId,
                PeriodsId = request.PeriodsId,
                ActivityType = 0
            };

            var soaRes = SOAHttpHelper.GetResposne<TrainPriceListResponse>(new TrainPriceListRequest
            {
                LineId = request.LineId,
                DepartureId = request.DepId,
                FromPlatment = request.PlatForm,
                ActivityId = request.ActivityId,
                PeriodsId = request.PeriodsId
            }, new RequestHeaderEntity("GetAllTrainPrice"));

            if (soaRes == null || soaRes.Body == null) return res;

            if (soaRes.Body.LinePrices == null || !soaRes.Body.LinePrices.Any()) return res;
            res.Prices.AddRange(
                soaRes.Body.LinePrices.Where(p => p.LineDate.Year == request.Year && p.LineDate.Month == request.Month)
                .Select(p => new PriceDetail
                {
                    LineDate = p.LineDate,
                    PriceId = 1,
                    PriceName = p.PriceName,
                    PriceType = 1,
                    AmountDirect = (int)p.LinePrice,
                    ResidualCount = p.ResidualCount,
                    IsActLiFan = p.IsActLiFan,
                    LiFanRuleDes = p.LiFanRuleDes
                }));

            return res;
        }

        /// <summary>
        /// 采销产品价格体系
        /// </summary>
        /// <param name="request">价格体系请求实体</param>
        /// <returns>价格体系响应实体</returns>
        private PriceStructureResponse GetCommonLinePriceStructure(PriceStructureRequest request)
        {
            var res = new PriceStructureResponse();

            var soaRes = SOAHttpHelper.GetResposne<LinePriceResponse>(new LinePriceRequest
            {
                LineId = request.LineId,
                CalendarPriceMethod = CalendarPriceMethod.GetAllCalendarPriceByLineId,
                IsCalendarShow = false,
                IVID = request.ActivityId,
                IVPeriodNo = request.PeriodsId
            }, new RequestHeaderEntity("GetLinePrice"));

            if (soaRes == null || soaRes.Body == null) return res;
            if (soaRes.Body.PriceList == null || !soaRes.Body.PriceList.Any()) return res;

            var ps = new PriceScheme()
            {
                SchemeId = 0,
                SchemeName = string.Empty,
                SchemeDes = string.Empty,
                SchemeType = 1,
                StockType = soaRes.Body.LineSeatType.Contains("切") ? 1 : 2,
                StockNum = 0
            };
            ps.Structures.AddRange(soaRes.Body.PriceList.Where(p => p.StartDate.Equals(request.LineDate))
                .Select(p => new StructureDetail
                {
                    PriceId = p.PriceId,
                    PriceName = p.PriceName,
                    PriceType = p.PriceType,
                    AmountDirect = p.AmountDirect
                }));

            res.Schemes.Add(ps);

            return res;
        }

        /// <summary>
        /// EB采销产品价格体系
        /// </summary>
        /// <param name="request">价格体系请求实体</param>
        /// <returns>价格体系响应实体</returns>
        private PriceStructureResponse GetEbCommonLinePriceStructure(PriceStructureRequest request)
        {
            var res = new PriceStructureResponse();

            var soaRes = SOAHttpHelper.GetResposne<UpgradeSchemeResponse>(new UpgradeSchemeRequest
            {
                LineId = request.LineId,
                PriceDate = request.LineDate
            }, new RequestHeaderEntity("GetUpgradeScheme"));

            if (soaRes == null || soaRes.Body == null) return res;
            if (soaRes.Body.UpgradeSchemeList == null || !soaRes.Body.UpgradeSchemeList.Any()) return res;

            res.Schemes.AddRange(
                soaRes.Body.UpgradeSchemeList.Select(p => new PriceScheme
                {
                    SchemeId = p.SchemeId,
                    SchemeName = p.SchemeName,
                    SchemeType = p.SchemeType,
                    SchemeDes = p.SchemeDes,
                    StockType = p.StockType,
                    StockNum = p.StockNum,
                    Structures = p.DatePriceList.Select(s => new StructureDetail
                    {
                        PriceId = s.TPDPId,
                        PriceType = s.PriceType,
                        PriceName = s.PriceTypeStr,
                        AmountDirect = s.Price
                    }).ToList()
                }));

            return res;
        }

        /// <summary>
        /// 采销资源价格体系总价
        /// </summary>
        /// <param name="pickUpPrice"></param>
        /// <returns></returns>
        private List<PickUpResource> GetPickUpPrice(GnySynthesizePriceResponse pickUpPrice)
        {
            var res = new List<PickUpResource>();

            if (pickUpPrice == null) return res;
            if (pickUpPrice.PriceList == null || !pickUpPrice.PriceList.Any()) return res;

            res.AddRange(pickUpPrice.PriceList.Select(p => new PickUpResource
            {
                PriceId = p.PriceId,
                PriceName = p.PriceName,
                PriceType = p.PriceType,
                IsShow = p.IsShow,
                ReckonPersons = p.ReckonPersons,
                SellPrice = p.SellPrice,
                SettlementPrice = p.SettlementPrice
            }));

            return res;
        }

        /// <summary>
        /// 获取机票航班信息
        /// </summary>
        /// <param name="flightRes"></param>
        /// <returns></returns>
        private List<FlightResource> GetFlightPrice(FlightComboListResponse flightRes)
        {
            var res = new List<FlightResource>();

            if (flightRes == null) return res;
            if (flightRes.FlightInfoSimpleList == null || !flightRes.FlightInfoSimpleList.Any()) return res;

            flightRes.FlightInfoSimpleList.ForEach(o =>
            {
                var singles = new List<FlightPrice>();

                o.FlightInfoList.ForEach(p =>
                {
                    var dtStart = p.flyOffTime.ToDateTime();
                    var dtEnd = p.arrivalTime.ToDateTime();
                    var time = dtEnd - dtStart;
                    var cabinName = "经济舱";

                    if (p.cabins != null && p.cabins.Any())
                    {
                        var desc = p.cabins.FirstOrDefault().roomDes;
                        cabinName = desc.Contains("经济舱") ? "经济舱" : desc.Contains("公务舱") ? "公务舱" : desc.Contains("头等舱") ? "头等舱" : "";
                    }

                    singles.Add(new FlightPrice
                    {
                        ResourceId = p.ResourceId,
                        ResourceType = p.ResourceType,
                        RouteType = p.RouteType,
                        FlyDate = dtStart.ToString("yyyy-MM-dd"),
                        OffTime = dtStart.ToString("HH:mm"),
                        ArriveTime = dtEnd.ToString("HH:mm"),
                        FlyTime = string.Format("约{0}小时{1}", time.Hours, time.Minutes <= 0 ? "" : time.Minutes.ToString() + "分钟"),
                        EquipmentCode = p.equipmentCode,
                        ACPlaneType = p.ACPlaneType,
                        FlightNo = p.flightNo,
                        AirCompanyCode = p.airCompanyCode,
                        AirCompanyName = p.airCompanyName,
                        StratAirportName = p.originAirportShortName,
                        StartCityName = p.originAirportCityName,
                        ArriveAirportName = p.arriveAirportShortName,
                        ArriveCityName = p.arriveAirportCityName,
                        BoardPoint = p.boardPoint,
                        OffPoint = p.offPoint,
                        StopNum = p.stopNum,
                        CabinName = cabinName,
                        RecFlight = p.recf,
                        AdultPrice = p.ResourceType == 1 ? p.AdultSellAmount : p.LowCabin.nkstp + p.ot + p.pt,
                        ChildPrice = p.ResourceType == 1 ? p.ChildSellAmount : p.LowCabin.sctp + p.ot + p.pt
                    });
                });

                res.Add(new FlightResource
                {
                    FlightInfoType = o.FlightInfoType,
                    AdultTotalPrice = o.TotalPrice,
                    ChildTotalPrice = o.TotalChildPrice,
                    SinglePrices = singles
                });
            });

            return res;
        }


        /// <summary>
        /// 获取火车票价格数据
        /// </summary>
        /// <param name="type">1：去程：2：返程</param>
        /// <param name="trainDate">出发日期</param>
        /// <param name="trains">所有班次信息</param>
        /// <returns></returns>
        private List<TrainResource> GetTrainPrice(int type, DateTime trainDate, List<DynamicTrainInfo> trains)
        {
            var res = new List<TrainResource>();

            trains.ForEach(g =>
            {
                var goDate = string.Format("{0} {1}", trainDate.ToString("yyyy-MM-dd"), g.FromTime).ToDateTime();
                var arriveDate = goDate.AddMinutes(g.RunTimeSpan.ToInt());
                var time = arriveDate - goDate;

                res.Add(new TrainResource
                {
                    RouteType = type,
                    TrainDate = trainDate.ToString("yyyy-MM-dd"),
                    TrainNo = g.TrainNo,
                    TrainClass = g.TrainClass,
                    FromTime = g.FromTime,
                    ToTime = g.ToTime,
                    RunTimeSpan = g.RunTimeSpan.ToInt(),
                    RunTime = string.Format("约{0}小时{1}", time.Hours, time.Minutes <= 0 ? "" : time.Minutes.ToString() + "分钟"),
                    FromStation = g.FromStation,
                    ToStation = g.ToStation,
                    FromStationCode = g.FromStationCode,
                    ToStationCode = g.ToStationCode,
                    FromPassType = g.FromPassType,
                    ToPassType = g.ToPassType,
                    TrainSeats = g.DictTickets.ToDictionary(p => p.Key, v => new TrainSeat
                    {
                        Price = v.Value.Price,
                        ChildPrice = v.Value.ChildPrice,
                        IsChildPrice = v.Value.IsChildPrice,
                        SeatName = v.Value.SeatName,
                        SeatState = v.Value.SeatState,
                        TicketCount = v.Value.TicketCount
                    })
                });
            });

            return res;
        }

        /// <summary>
        /// 获取酒店资源
        /// </summary>
        /// <param name="lineId">产品ID</param>
        /// <param name="date">入住日期</param>
        /// <returns>酒店资源信息</returns>
        private Tuple<int, List<HotelResource>> GetHotelResource(int lineId, DateTime date)
        {
            var hotels = new List<HotelResource>();

            var increasePrice = 0;
            var hotelRes = new List<DynamicHotelResource>();
            using (var resCon = new DbContext(DBOperationType.Read, DatabaseConnection.Db_TcTourismResource))
            {
                var addPrices = resCon.GetContext<TourismProductAddPrice>().Query("TPAPLineId=? and TPAPFlag=1", string.Empty, lineId);
                if (addPrices != null && addPrices.Any()) increasePrice = (int)addPrices.Sum(a => a.TPAPPrice);
                hotelRes = resCon.GetContext<DynamicHotelResource>().Query("TDHRLineId=?", string.Empty, lineId);
                if (hotelRes == null || !hotelRes.Any()) return null;
            }

            var hotelPrice = 0;

            foreach (var item in hotelRes.OrderBy(h => h.TDHRBeginDay))
            {
                var checkInDate = date.AddDays(item.TDHRBeginDay - 1);
                var checkOutDate = date.AddDays(item.TDHREndDay);
                var nights = (item.TDHREndDay - item.TDHRBeginDay) + 1;

                var res = SOAHttpHelper.GetResposne<RoomInfoResponseEntity>(new RoomInfoRequestEntity
                {
                    HotelId = item.TPDHotelId,
                    RoomId = item.TPDHRoomId,
                    PricePolicyId = item.TPDHPolicyId,
                    ComeDate = checkInDate,
                    LeaveDate = checkOutDate
                }, new RequestHeaderEntity("GetHotelRoomsWithGuaranteePolicy"));
                if (res == null || res.Body == null || res.Body.RoomsWithPolicyData == null || !res.Body.RoomsWithPolicyData.Any()) break;
                var hotelRoom = res.Body.RoomsWithPolicyData.FirstOrDefault().HotelRoom;
                if (hotelRoom == null) break;
                var roomPolicy = res.Body.RoomsWithPolicyData.FirstOrDefault().RoomPolicyList.FirstOrDefault();
                if (roomPolicy == null) break;

                hotels.Add(new HotelResource
                {
                    HotelId = hotelRoom.RoomId,
                    HotelName = hotelRoom.HotelName,
                    HotelImgUrl = hotelRoom.BaseImgUrl + "" + hotelRoom.ImgUrl,
                    HotelPrice = (int)roomPolicy.ProtocolAmountSum,
                    RoomId = hotelRoom.RoomId,
                    RoomName = hotelRoom.RoomName,
                    PolicyId = roomPolicy.PolicyId,
                    PolicyName = roomPolicy.PolicyName,
                    CheckInDate = checkInDate.ToYYYYMMDDString(),
                    CheckOutDate = checkOutDate.ToYYYYMMDDString(),
                    Nights = nights
                });
            }

            return new Tuple<int, List<HotelResource>>(increasePrice, hotels);
        }

        #endregion
    }
}