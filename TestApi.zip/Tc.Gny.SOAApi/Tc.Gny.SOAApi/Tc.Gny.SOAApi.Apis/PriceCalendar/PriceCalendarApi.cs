﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tc.Gny.SOAApi.ApiBase.Base;
using Tc.Gny.SOAApi.ApiModels.PriceCalendar;
using Tc.Gny.SOAApi.Apis.Filter;
using Tc.Gny.SOAApi.Services.PriceCalendar;

namespace Tc.Gny.SOAApi.Apis.PriceCalendar
{
    /// <summary>
    /// 价格日历统一接口
    /// </summary>
    [Api("Price", "价格日历统一接口")]
    public class PriceCalendarApi : BaseApi
    {
        /// <summary>
        /// 价格日历接口
        /// </summary>
        private IPriceCalendarService _pcService = new PriceCalendarService();

        /// <summary>
        /// 价格日历呈现
        /// </summary>
        /// <param name="request">请求实体</param>
        /// <returns>响应实体</returns>
        [CallAuthFilter]
        [D("价格日历呈现")]
        public PriceCalendarResponse Calendar(PriceCalendarRequest request)
        {
            return _pcService.GetCalendarData(request);
        }

        /// <summary>
        /// 价格体系明细-默认产品，采销产品，火车票固定打包
        /// </summary>
        /// <param name="request">请求实体</param>
        /// <returns>响应实体</returns>
        [CallAuthFilter]
        [D("采销价格体系")]
        public PriceStructureResponse Structure(PriceStructureRequest request)
        {
            return _pcService.GetStructureData(request);
        }

        /// <summary>
        /// 地接价格体系
        /// </summary>
        /// <param name="request">请求实体</param>
        /// <returns>响应实体</returns>
        [CallAuthFilter]
        [D("地接价格体系")]
        public LocalTravelStructureResponse LocalTravelStructure(LocalTravelPriceStructureRequest request)
        {
            return _pcService.GetLocalTravelStructureData(request);
        }

        /// <summary>
        /// 动态机票价格体系
        /// </summary>
        /// <param name="request">请求实体</param>
        /// <returns>响应实体</returns>
        [CallAuthFilter]
        [D("动态机票价格体系")]
        public FlightPriceStructureResponse FlightStructure(FlightPriceStructureRequest request)
        {
            return _pcService.GetFlightStructureData(request);
        }

        /// <summary>
        /// 动态火车票价格体系
        /// </summary>
        /// <param name="request">请求实体</param>
        /// <returns>响应实体</returns>
        [CallAuthFilter]
        [D("动态火车票价格体系")]
        public TrainPriceStructureResponse TrainStructure(TrainPriceStructureRequest request)
        {
            return _pcService.GetTrainStructureData(request);
        }
    }
}