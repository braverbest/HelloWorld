﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tc.Gny.SOAApi.ApiBase;

namespace Tc.Gny.SOAApi.Apis.RaiseEvent
{
    public class RaiseEvent
    {
        public RaiseEvent()
        {
            ApiExecFactory.OnApiExecuting += ApiExecFactory_OnApiExecuting;
            ApiExecFactory.OnApiExecutedSuccess += ApiExecFactory_OnApiExecutedSuccess;
            ApiExecFactory.OnApiExecutedError += ApiExecFactory_OnApiExecutedError;
        }
      

        /// <summary>
        /// api执行前事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void ApiExecFactory_OnApiExecuting(object sender, ApiBase.Args.ApiExecutingEventArgs e)
        {

        }

        /// <summary>
        /// api执行成功事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void ApiExecFactory_OnApiExecutedSuccess(object sender, ApiBase.Args.ApiExecutedSuccessEventArgs e)
        {

        }

        /// <summary>
        /// api执行失败事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void ApiExecFactory_OnApiExecutedError(object sender, ApiBase.Args.ApiExecutedErrorEventArgs e)
        {
            
        }

    }
}
