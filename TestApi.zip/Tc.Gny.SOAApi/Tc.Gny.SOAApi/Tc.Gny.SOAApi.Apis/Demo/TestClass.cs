﻿using Tc.Gny.SOAApi.ApiBase.Base;
using Tc.Gny.SOAApi.ApiBase.Core;
using Tc.Gny.SOAApi.ApiModels;

namespace Tc.Gny.SOAApi.Apis.Demo
{
     [Api("tapi", "这是一个测试调用的API")]
    public class TestClass : BaseApi
    {
         protected override void OnLoad(Kernel knl)
         {
             base.OnLoad(knl);
             knl.GetApi<TestCall>("TestCall").OnTest += TestClass_OnTest;
         }

         void TestClass_OnTest(object sender, Framework.Core.Args.DataEventArgs<string> e)
         {

         }

         [D("测试方法test")]
        public string Test(string name)
        {
           var alllgc=  Kernel.GetAllLgc();
            return "ok";
        }

        [D("测试方法test1")]
        public TestPara Test1(TestPara name, string val)
        {
            var obj = Kernel.GetApi<TestCall>("TestCall").Test1(name, val);
            return obj;
        }

        [D("测试方法test2")]
        public string Test2(string name, string val)
        {
            return "test2";
        }

        [D("测试方法test3")]
        public void Test3()
        {

        }
    }
}
