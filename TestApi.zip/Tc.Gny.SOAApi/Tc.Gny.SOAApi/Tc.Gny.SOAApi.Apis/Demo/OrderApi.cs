﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tc.Gny.Framework.Core.Args;
using Tc.Gny.SOAApi.ApiBase.Base;

namespace Tc.Gny.SOAApi.Apis.Demo
{
    [Api("orderapi","下单接口")]
    public class OrderApi:BaseApi
    {
        public event EventHandler<DataEventArgs<string>> OnPerSubOrder;

        public event EventHandler<DataEventArgs<string>> OnSubOk;

        protected virtual void OnOnSubOk(DataEventArgs<string> e)
        {
            EventHandler<DataEventArgs<string>> handler = OnSubOk;
            if (handler != null) handler(this, e);
        }

        protected virtual void OnOnPerSubOrder(DataEventArgs<string> e)
        {
            EventHandler<DataEventArgs<string>> handler = OnPerSubOrder;
            if (handler != null) handler(this, e);
        }

        [D("测试下单")]
        public string SubOrder()
        {
            //下单前
            OnOnPerSubOrder(new DataEventArgs<string>("123"));

            //下单成功
            OnOnSubOk(new DataEventArgs<string>("123"));
            return "ok";
        }
    }
}
