﻿using System;
using Tc.Gny.Framework.Core.Args;
using Tc.Gny.SOAApi.ApiBase.Base;
using Tc.Gny.SOAApi.ApiModels;
using Tc.Gny.SOAApi.Apis.Filter;
using Tc.Gny.Framework.Core;
using System.Collections.Generic;
using Tc.Gny.SOAApi.EOrder.IOrder;
using Tc.Gny.SOAApi.Entities.EOrder.Order;

namespace Tc.Gny.SOAApi.Apis.Demo
{
    [Api("TestCall", "这是一个测试被调用的API")]
    public class TestCall : BaseApi
    {
        private static readonly IOrderDao _IOrderDao = new IOrderDao();

        public event EventHandler<DataEventArgs<string>> OnTest;

        protected virtual void OnOnTest(DataEventArgs<string> e)
        {
            EventHandler<DataEventArgs<string>> handler = OnTest;
            if (handler != null) handler(this, e);
        }

        [CallAuthFilter]
        [D("测试方法test")]
        public string Test(string name)
        {
            return "ok";
        }

        [CallAuthFilter]
        [D("测试方法test1")]
        public TestPara Test1(TestPara name, string val = "1212")
        {
            OnOnTest(new DataEventArgs<string>(val));
            return name;
        }

        [D("测试方法test2")]
        public void Test2(int name, DateTime val)
        {

        }

        [D("我的测试")]
        public dynamic MyTest()
        {
            var list = ((Func<dynamic>)_IOrderDao.MyTest()).Invoke();
            return list;
        }

        [D("获取订单列表")]
        public dynamic GetCLineOrderList(CLineOrderQueryModel entity)
        {
            Func<CLineOrderQueryModel, dynamic> func = _IOrderDao.GetCLineOrderList();
            var list = func.Invoke(entity);

            return list;
        }
    }
}
