﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tc.Gny.SOAApi.ApiBase.Base;
using Tc.Gny.SOAApi.ApiBase.Core;

namespace Tc.Gny.SOAApi.Apis.Demo
{
    public class HotelApi:BaseApi
    {
        protected override void OnLoad(Kernel knl)
        {
            base.OnLoad(knl);
            knl.GetApi<OrderApi>("orderapi").OnSubOk += (x, y) =>
            {
                //下酒店
            };
        }
    }
}
