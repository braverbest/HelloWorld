﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tc.Gny.Framework.Core.Common;
using Tc.Gny.SOAApi.ApiBase.Fliter;
using Tc.Gny.SOAApi.ApiBase.Result;
using Tc.Gny.SOAApi.ApiModels;

namespace Tc.Gny.SOAApi.Apis.Filter
{
    /// <summary>
    /// 进行参数和权限验证的soa接口
    /// </summary>
    public class CallAuthFilter : AuthFilter
    {
        public override void OnAuth(AuthContext context)
        {
            var appid = context.Request.QueryString["appid"];
            var token = context.Request.QueryString["token"];
           
            if (appid.IsNullOrEmpty() ||  !CallCfg.Instance.CallCfgs.ContainsKey(appid))
            {
                context.Result = new ApiResult() { ResultCode = ResultCode.NoRights };
                return;
            }

            var key = CallCfg.Instance.CallCfgs[appid].AppKey;

            var keys = context.Request.Form.Keys;
            var parastr = "";
            foreach (var k in keys)
            {
                parastr += context.Request.Form[k.ToString()];
            }

            var currentToken = Tc.Gny.Framework.Core.Security.Encypt.MD5(context.ApiName + context.MethodName + parastr + key);
            if (!currentToken.Equals(token))
            {
                context.Result = new ApiResult() { ResultCode = ResultCode.NoRights };
                return;
            }
        }
    }
}
