﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tc.Gny.SOAApi.Entities.EOrder.Order;
using Tc.Gny.SOAApi.EOrder.OrderImpl;

namespace Tc.Gny.SOAApi.EOrder.IOrder
{
    /// <summary>
    /// 订单接口类
    /// </summary>
    /// { Created At Time:[ 2016/3/25 9:59 ], By User:wcj21259, On Machine:WCJ }
    public class IOrderDao
    {
        private static readonly OrderDaoImpl _OrderDaoImpl = new OrderDaoImpl();

        public dynamic MyTest()
        {
            Func<dynamic> func = () =>
            {
                return _OrderDaoImpl.GetList();
            };

            return func;
        }

        /// <summary>
        /// 获取订单列表.
        /// </summary>
        /// <returns></returns>
        /// { Created At Time:[ 2016/3/29 14:32 ], By User:wcj21259, On Machine:WCJ }
        public Func<CLineOrderQueryModel, dynamic> GetCLineOrderList()
        {
            Func<CLineOrderQueryModel, dynamic> func = (entity) =>
             {
                 return _OrderDaoImpl.GetCLineOrderList(entity);
             };

            return func;
        }
    }
}
